
## v7.4 — naya logo (vortex)
- App icon, splash animation aur home ka logo ab vortex wala hai (res/drawable-nodpi/logo_vortex.png, ic_launcher.png). Splash mein ghoomta hua andar aata hai, phir "JARVIS" likha aata hai.
- Logo badalna ho to inhi do PNG ko replace karo.
