package com.jarvis.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LangTest {
    @Test
    fun romanHinglishIsDetected() {
        assertTrue(Lang.isRoman("Kya haal chal"))
        assertFalse(Lang.isRoman("क्या हाल चाल"))
    }

    @Test
    fun codeAndMarkdownAreRemovedBeforeSpeaking() {
        val spoken = Lang.cleanForSpeech("**Ye** code hai:\n```kotlin\nval a = 1\n```\nBas.")
        assertFalse(spoken.contains("val a"))
        assertFalse(spoken.contains("*"))
    }

    @Test
    fun languageTagIsParsedAndStripped() {
        val (mood, text) = Persona.parse("[mood:HAPPY] [lang:en] Hello there")
        assertEquals(Mood.HAPPY, mood)
        assertEquals("Hello there", text)
        assertEquals("en", Persona.lang)
    }
}
