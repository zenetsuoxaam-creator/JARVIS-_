package com.jarvis.app

import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class LocalBrainTest {
    @Test
    fun greetingIsAnsweredLocally() {
        assertNotNull(LocalBrain.reply("hello"))
    }

    @Test
    fun unknownTextFallsThroughToGemini() {
        assertNull(LocalBrain.reply("xyzzy kuch bhi"))
    }
}
