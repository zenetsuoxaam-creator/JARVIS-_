package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Phone control ka core. User ko Settings > Accessibility mein ye service ON karni hogi.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun scroll(forward: Boolean): Boolean {
        val node = findScrollable(rootInActiveWindow) ?: return false
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                     else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return node.performAction(action)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            findScrollable(n.getChild(i))?.let { return it }
        }
        return null
    }

    /** Screen par jis text wala element ho, usper click karta hai (e.g. "Play", "Pause"). */
    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** Jo text box focus mein hai usme likhta hai. */
    fun typeText(text: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build()
        dispatchGesture(g, null, null)
    }

    fun screenshot(): Boolean = if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false
    fun lockScreen(): Boolean = if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
    fun powerMenu() = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    /** Ungli ki swipe: "left" = ungli daayen se baayen jaati hai. */
    fun swipe(dir: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val pts = when (dir) {
            "left" -> listOf(w * 0.8f, h * 0.5f, w * 0.2f, h * 0.5f)
            "right" -> listOf(w * 0.2f, h * 0.5f, w * 0.8f, h * 0.5f)
            "up" -> listOf(w * 0.5f, h * 0.75f, w * 0.5f, h * 0.25f)
            else -> listOf(w * 0.5f, h * 0.25f, w * 0.5f, h * 0.75f)
        }
        val path = Path().apply { moveTo(pts[0], pts[1]); lineTo(pts[2], pts[3]) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build()
        return dispatchGesture(g, null, null)
    }

    /** Screen par jo text dikh raha hai wo jodkar deta hai (padh kar sunane ke liye). */
    fun readScreen(): String {
        val out = ArrayList<String>()
        collectText(rootInActiveWindow, out)
        return out.distinct().take(40).joinToString(". ")
    }

    private fun collectText(n: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (n == null || out.size > 80) return
        val t = n.text?.toString()?.trim().orEmpty()
        val d = n.contentDescription?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) out.add(t) else if (d.isNotEmpty()) out.add(d)
        for (i in 0 until n.childCount) collectText(n.getChild(i), out)
    }

    /** YouTube ki tarah double-tap: right side = 10s aage, left side = 10s peeche. */
    fun doubleTapSide(forward: Boolean) {
        val dm = resources.displayMetrics
        val x = if (forward) dm.widthPixels * 0.8f else dm.widthPixels * 0.2f
        val y = dm.heightPixels * 0.4f
        tap(x, y)
        Handler(Looper.getMainLooper()).postDelayed({ tap(x, y) }, 120)
    }
}
