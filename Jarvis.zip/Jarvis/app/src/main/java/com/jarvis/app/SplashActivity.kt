package com.jarvis.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.view.View

/**
 * App kholte hi pehle ye animation: rings andar se phailti hain, ghoomti hain,
 * core flash hota hai, phir "JARVIS" likha aata hai aur home par fade ho jaata hai.
 */
class SplashActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var tone: ToneGenerator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#E7EAF0")
        window.navigationBarColor = Color.parseColor("#E7EAF0")
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 32).also { it.startTone(ToneGenerator.TONE_PROP_ACK, 260) }
        ui.postDelayed({ tone?.release(); tone = null }, 500)
        val v = SplashView(this)
        setContentView(v)
        ui.postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, TOTAL_MS)
    }

    override fun onDestroy() { ui.removeCallbacksAndMessages(null); tone?.release(); tone = null; super.onDestroy() }

    companion object { const val TOTAL_MS = 3800L }
}

private class SplashView(ctx: Context) : View(ctx) {
    private val bmp = BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_vortex)
    private val img = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN); colorFilter = android.graphics.ColorMatrixColorFilter(android.graphics.ColorMatrix().apply { setSaturation(0.08f) }) }
    private val fade = Paint().apply { color = Color.parseColor("#E7EAF0") }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#263244"); textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); letterSpacing = 0.35f
    }
    private val t0 = System.currentTimeMillis()

    private fun ease(x: Float): Float { val c = x.coerceIn(0f, 1f); return 1f - (1f - c) * (1f - c) * (1f - c) }

    override fun onDraw(c: Canvas) {
        c.drawColor(Color.parseColor("#E7EAF0"))
        val t = (System.currentTimeMillis() - t0) / 1000f
        val cx = width / 2f
        val cy = height * 0.42f
        val size = minOf(width, height) * 0.85f

        // vortex: chhota + tez ghoomta hua aata hai, phir dheere ghoomta rehta hai
        val appear = ease(t / 1.4f)
        val scale = 0.55f + 0.45f * appear
        val spin = (1f - ease(t / 2.8f)) * 300f + t * 8f
        img.alpha = (255 * ease(t / 0.8f)).toInt()
        c.save()
        c.translate(cx, cy); c.rotate(spin); c.scale(scale * size / bmp.width, scale * size / bmp.height)
        c.drawBitmap(bmp, -bmp.width / 2f, -bmp.height / 2f, img)
        c.restore()

        // naam
        val tx = ease((t - 1.5f) / 0.7f)
        text.textSize = size * 0.10f; text.alpha = (255 * tx).toInt()
        c.drawText("J A R V I S", cx, cy + size * 0.62f + (1f - tx) * size * 0.04f, text)

        // aakhir mein fade out
        if (t > 2.7f) {
            fade.alpha = (255 * ease((t - 2.7f) / 1.1f)).toInt()
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fade)
        }
        postInvalidateOnAnimation()
    }
}
