package com.jarvis.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast

/** Bina UI ke: photo delete (system popup ke saath) ya WhatsApp share. */
class PhotoActionActivity : Activity() {
    private val deleteRequest = 301

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uris: ArrayList<Uri> = intent.getParcelableArrayListExtra("uris") ?: arrayListOf()
        if (uris.isEmpty()) { finish(); return }

        when (intent.getStringExtra("action")) {
            "delete" -> {
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                        startIntentSenderForResult(pi.intentSender, deleteRequest, null, 0, 0, 0)
                    } catch (e: Exception) {
                        Toast.makeText(this, "Delete request nahi ban paayi", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                } else {
                    // Android 10 aur neeche: seedha delete (permission ke hisaab se)
                    uris.forEach { try { contentResolver.delete(it, null, null) } catch (_: Exception) {} }
                    finish()
                }
            }
            "share" -> {
                val share = Intent(Intent.ACTION_SEND).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_STREAM, uris.first())
                    setPackage("com.whatsapp")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try { startActivity(share) }
                catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "WhatsApp install nahi hai", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
            else -> finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == deleteRequest) {
            Toast.makeText(
                this,
                if (resultCode == RESULT_OK) "Photo delete ho gayi" else "Delete cancel hua",
                Toast.LENGTH_SHORT
            ).show()
        }
        finish()
    }
}
