package com.jarvis.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Reply(val text: String, val mood: Mood? = null)

object CommandRouter {
    private val history = ArrayList<Pair<String, String>>() // role, text
    private const val NO_SERVICE = "Phone control ON nahi hai. Settings (⚙) mein Accessibility ON karo."

    /** Background thread par chalta hai. Order: device commands -> local dost wale jawab -> Gemini. */
    fun process(ctx: Context, raw: String): Reply {
        val t = raw.trim()
        syncBanter(ctx)
        Persona.moodFromUser(t)?.let { Persona.mood = it }
        device(ctx, t)?.let { return Reply(it, Persona.mood) }
        LocalBrain.reply(t)?.let { (m, txt) -> Persona.mood = m; return Reply(txt, m) }
        return askGemini(ctx, t)
    }

    private fun device(ctx: Context, raw: String): String? {
        val svc = JarvisAccessibilityService.instance
        fun m(p: String) = Regex(p, RegexOption.IGNORE_CASE).find(raw)

        // ---- Confirmation (call/SMS/WhatsApp bhejne se pehle) ----
        Pending.run?.let { run ->
            if (Regex("^(haan|haa|yes|kar do|bhej do|ok|theek hai)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) {
                Pending.clear(); return run()
            }
            if (Regex("^(nahi|no|cancel|mat|ruk)\\b", RegexOption.IGNORE_CASE).containsMatchIn(raw)) {
                Pending.clear(); return "Theek hai, cancel kar diya."
            }
        }

        // ---- Connected device control (Bluetooth HID; pehle permission, phir kaam) ----
        DeviceControl.handle(ctx, raw)?.let { return it }

        // ---- Gali/masti ON-OFF ----
        m("^gali (chalu|on|band|off) karo$")?.let {
            val on = it.groupValues[1].lowercase().let { v -> v == "chalu" || v == "on" }
            ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("banter", on).apply()
            Persona.banter = on
            return if (on) "Haan bhai, ab full dosti wali masti aur halki gaali chalu, saale 😈" else "Theek hai, gaali band. Saaf-suthri masti chalegi."
        }

        // ---- GTA V: sirf official raasta (unofficial browser port nahi kholta) ----
        m("gta ?(?:v|5)\\b.*(?:browser|kholo|chalao|khelo|lagao)|(?:browser|kholo|chalao|khelo|lagao).*gta ?(?:v|5)\\b")?.let {
            openWeb(ctx, "https://www.rockstargames.com/gta-v")
            return "GTA V ka official page khol diya. Browser wala 'fiveplay.lol' jaisa unofficial port main nahi kholta: wo leaked code par bana hai, " +
                   "copyright ke against hai aur safety reports mein risky (naya domain, donation button) bataya gaya hai. " +
                   "Khelna ho to Steam/Epic/Rockstar launcher se ya cloud gaming se khelo."
        }

        // ---- Browser mein movie / anime (free + legal sources) ----
        m("^(?:browser (?:me|mein|pe) )?(movie|film|anime) (.+?)(?: browser (?:me|mein|pe))? (?:lagao|chalao|dikhao)$")?.let {
            val name = it.groupValues[2].trim()
            return if (it.groupValues[1].equals("anime", true)) {
                openWeb(ctx, DeviceUrls.anime(name))
                "\"$name\" anime ke legal results browser mein khol diye (Crunchyroll/YouTube/Tubi). Episode chun lo."
            } else {
                openWeb(ctx, DeviceUrls.freeMovies(name))
                "\"$name\" ke free legal results khol diye (YouTube/Tubi/Pluto TV/Internet Archive). Jo achha lage chun lo. Pirated sites nahi kholta."
            }
        }

        // ---- AI prompt banana (jitna lamba bolo) + prompt se image ----
        m("^(?:ai )?(video )?prompt (?:banao|bana do|likho) (.+)$")?.let {
            return makePrompt(ctx, it.groupValues[2], it.groupValues[1].isNotBlank())
        }
        m("^(?:is |ye |isi |last )?prompt se (?:image|photo|tasveer) (?:banao|bana do)$")?.let {
            val p = LastPrompt.get(ctx) ?: return "Pehle 'prompt banao <idea> 200 word' bolo, phir 'is prompt se image banao'."
            return makeImage(ctx, p)
        }
        m("^(?:is |ye |isi |last )?prompt se video (?:banao|bana do)$|^ai video (?:banao|bana do).*$")?.let {
            return "AI video banane ke liye alag video-generation API (Veo, Kling, Runway jaisi) chahiye, jo free Gemini key par aam taur par nahi milti, isliye app mein video nahi hai. " +
                   "Main uska prompt bana deta hoon jise tum un tools mein paste kar sakte ho: 'video prompt banao <idea> 150 word'. Photo ke liye: 'prompt se image banao'."
        }

        // ---- Message reply / smart reading ----
        m("^reply (.+)$")?.let {
            val who = NotifService.lastSender
            if (who.isEmpty()) return "Kisko reply karun? Pehle koi message aane do."
            return confirmSend(ctx, who, it.groupValues[1], NotifService.lastPkg == "com.whatsapp")
        }
        m("^message padh ke batao (on|chalu karo)$")?.let {
            ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("smart_read", true).apply()
            return "Message padh ke batana ON kar diya."
        }
        m("^message padh ke batao (off|band karo)$")?.let {
            ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("smart_read", false).apply()
            return "Message padh ke batana OFF kar diya."
        }

        // ---- Termux: user ke confirm ke baad hi command chalegi ----
        m("^termux (?:mein|me|pe) (.+)$")?.let {
            val cmd = it.groupValues[1].trim()
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Termux mein ye command chalaun? `$cmd`\n'haan' ya 'nahi' bolo."
        }
        m("^termux install (.+)$")?.let {
            val cmd = "pkg install -y " + it.groupValues[1].trim()
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Termux mein ye install karun? `$cmd`\n'haan' ya 'nahi' bolo."
        }

        // ---- Monster band karna ----
        m("^(?:monster|jarvis) band karo$")?.let {
            val mon = MonsterActivity.instance
            return if (mon == null) "Monster khula hi nahi hai." else { mon.finish(); "Monster band kar diya." }
        }

        // ---- Bhasha badlo ----
        m("^(?:bhasha|language|lang) (?:badlo |change )?(.+)$")?.let {
            val code = Lang.codeFromName(it.groupValues[1])
            if (code != null) {
                Lang.setPref(ctx, code)
                return "Theek hai. Bhasha: " + Lang.labelOf(code)
            }
        }

        // ---- Cast / Bluetooth ----
        m("^(?:screen )?cast (?:karo|kholo|on karo|chalu karo)$|^screen cast(?: karo)?$")?.let {
            return try {
                ctx.startActivity(Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Cast screen khol di. Device chuno, phone ki screen wahan dikhegi."
            } catch (e: Exception) { "Is phone mein cast screen nahi khuli." }
        }
        m("^bluetooth (?:remote )?(?:kholo|khol do|on karo|chalu karo)$")?.let {
            ctx.startActivity(Intent(ctx, BtRemoteActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Bluetooth remote khol diya. Device chuno, phir touchpad, keyboard aur media buttons chalenge."
        }
        m("^bluetooth (?:settings|connect karo|device)$")?.let {
            return try {
                ctx.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Bluetooth settings khol di."
            } catch (e: Exception) { "Bluetooth settings nahi khuli." }
        }

        // ---- Phone control (Accessibility) ----
        m("^screenshot (?:lo|le lo|kheencho)$")?.let { return act(svc) { s -> s.screenshot() } }
        m("^(?:phone |screen )?lock karo$")?.let { return act(svc) { s -> s.lockScreen() } }
        m("^power menu$")?.let { return act(svc) { s -> s.powerMenu() } }
        m("^quick settings$")?.let { return act(svc) { s -> s.quickSettings() } }
        m("^swipe (left|right|up|down)$")?.let { return act(svc) { s -> s.swipe(it.groupValues[1]) } }
        m("^(.+?) (?:pe|par) click karo$")?.let {
            if (svc == null) return NO_SERVICE
            val label = it.groupValues[1].trim()
            return if (svc.clickText(label)) "Ho gaya." else "\"$label\" screen par nahi mila."
        }
        m("^screen padho$")?.let {
            if (svc == null) return NO_SERVICE
            val t = svc.readScreen()
            return if (t.isEmpty()) "Screen par padhne layak kuch nahi mila." else t
        }

        // ---- Notifications ----
        m("^notifications? (?:padho|dikhao|batao|check karo)$")?.let {
            val n = NotifService.latest(5)
            return if (n.isEmpty()) "Koi nayi notification nahi hai (ya Notification access OFF hai)."
                   else n.joinToString("\n") { "• $it" }
        }

        // ---- Files: PDF, Word, Excel ----
        m("^(pdf|docx|word|excel|xlsx) (?:banao|bana do) (.+)$")?.let {
            return makeFile(ctx, it.groupValues[1].lowercase(), it.groupValues[2])
        }
        // ---- GitHub: search (bina key) aur clone (Termux, 'haan' ke baad) ----
        m("^github (?:search|dhoondo) (.+)$")?.let { return githubSearch(it.groupValues[1]) }
        m("^github clone ([\\w.-]+/[\\w.-]+)$")?.let {
            val repo = it.groupValues[1]
            Pending.set("termux") { Termux.run(ctx, "git clone https://github.com/$repo") }
            return "Termux mein ye clone karun? git clone https://github.com/$repo\n'haan' ya 'nahi' bolo."
        }
        // ---- APK / Android build workspace: only apps the user owns or is authorized to modify ----
        m("^android build (.+)$")?.let {
            val project = it.groupValues[1].trim()
            if (!safeWorkspacePath(project)) return "Path mein unsupported characters hain. Simple path use karo, jaise ~/storage/shared/MyApp."
            val q = shellQuote(project)
            val cmd = "cd $q && chmod +x ./gradlew && ./gradlew assembleDebug"
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Apne Android project ka debug APK build karne ke liye Gradle command chalaun? Output project/app/build/outputs/apk/debug/ mein aayega.\n$q\n'haan' ya 'nahi' bolo."
        }
        m("^apk edit prepare (\\S+\\.apk)$")?.let {
            val apk = it.groupValues[1].trim()
            if (!safeWorkspacePath(apk)) return "APK path mein unsupported characters hain."
            val base = apk.substringAfterLast('/').removeSuffix(".apk")
            val out = "/data/data/com.termux/files/home/jarvis_apk_work/$base"
            val cmd = "mkdir -p /data/data/com.termux/files/home/jarvis_apk_work && apktool d -f ${shellQuote(apk)} -o ${shellQuote(out)}"
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Sirf apne ya permission wale APK ko editable project mein decode karun? Folder: $out\nIsse smali/resources milenge; JADX Java output ko seedha rebuild nahi kiya ja sakta.\n'haan' ya 'nahi' bolo."
        }
        m("^apk edit build (.+)$")?.let {
            val folder = it.groupValues[1].trim()
            if (!safeWorkspacePath(folder)) return "Folder path mein unsupported characters hain."
            val q = shellQuote(folder)
            val out = "/data/data/com.termux/files/home/jarvis_apk_work/modified-unsigned.apk"
            val signed = "/data/data/com.termux/files/home/jarvis_apk_work/modified-signed.apk"
            val ks = "/data/data/com.termux/files/home/.keystore/jarvis-debug.jks"
            val cmd = "mkdir -p /data/data/com.termux/files/home/jarvis_apk_work /data/data/com.termux/files/home/.keystore && apktool b $q -o ${shellQuote(out)} && " +
                "(test -f ${shellQuote(ks)} || keytool -genkeypair -v -keystore ${shellQuote(ks)} -storepass android -alias jarvis -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=JARVIS Debug,O=Local,C=IN') && " +
                "apksigner sign --ks ${shellQuote(ks)} --ks-pass pass:android --key-pass pass:android --out ${shellQuote(signed)} ${shellQuote(out)} && apksigner verify ${shellQuote(signed)}"
            Pending.set("termux") { Termux.run(ctx, cmd) }
            return "Edited APK rebuild + debug-key signing chalaun? Ye original developer signature ko preserve nahi karega; modified APK original app ke upar update ki tarah install nahi hoga. Sirf authorized APK par. Output: /data/data/com.termux/files/home/jarvis_apk_work/modified-signed.apk\n'haan' ya 'nahi' bolo."
        }

        // ---- APK analysis (sirf dekhna): apne app / open-source / security samajhne ke liye ----
        m("^apk (?:info|check) (\\S+\\.apk)$")?.let {
            val f = it.groupValues[1].replace("'", "")
            Pending.set("termux") { Termux.run(ctx, "(aapt dump badging '$f' 2>/dev/null | head -40) || unzip -l '$f' | head -60") }
            return "APK ki info Termux mein dikhaun (package, permissions, files)? $f\n'haan' ya 'nahi' bolo."
        }
        m("^apk (?:decompile|code dekho) (\\S+\\.apk)$")?.let {
            val f = it.groupValues[1].replace("'", "")
            Pending.set("termux") { Termux.run(ctx, "jadx -d ~/jadx_out '$f' || echo 'jadx install karo: pkg install jadx'") }
            return "Dhyan do: ye sirf apne app, open-source app ya security samajhne ke liye hai. Doosron ka app copy/repack karna allowed nahi.\n" +
                   "Code padhne ke liye ~/jadx_out mein nikalun? $f\n'haan' ya 'nahi' bolo."
        }
        // ---- App: tumhare idea se ORIGINAL Android project (zip) ----
        m("^app (?:banao|bana do) (.+)$")?.let { return makeApp(ctx, it.groupValues[1]) }
        // ---- Game: tumhare idea (ya 2-3 games ke mechanics ko mila kar) ORIGINAL HTML5 game ----
        m("^game (?:banao|bana do) (.+)$")?.let { return makeGame(ctx, it.groupValues[1]) }
        // ---- Kisi bhi type ki file: "file banao notes.txt <topic>" ----
        m("^file (?:banao|bana do) (\\S+\\.[A-Za-z0-9]{1,8}) (.+)$")?.let {
            return makeAnyFile(ctx, it.groupValues[1], it.groupValues[2])
        }
        // ---- Image generation ----
        m("^(?:image|photo|tasveer) (?:banao|bana do) (.+)$")?.let {
            return makeImage(ctx, it.groupValues[1])
        }
        // ---- Monster page ----
        m("^(?:monster|hologram) (?:kholo|khol do|dikhao)$")?.let {
            ctx.startActivity(Intent(ctx, MonsterActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Monster khol diya."
        }

        // ---- Play Store / Google APK (install user khud confirm karega) ----
        m("^(?:play ?store|playstore) (?:pe|par|pr) (.+?)(?: (?:install|download))?(?: karo| kar do)?$")?.let {
            return PhoneTools.playStore(ctx, it.groupValues[1].trim())
        }
        m("^google (?:se|pe|par) (.+?) apk (?:dhoondo|dhundo|search karo)$")?.let {
            return PhoneTools.googleApk(ctx, it.groupValues[1].trim())
        }
        m("^(.+?) (?:install|download) karo$")?.let {
            return PhoneTools.playStore(ctx, it.groupValues[1].trim())
        }

        // ---- Photos: dekhna, delete (confirm ke saath), WhatsApp share, click ----
        m("^(?:aaj ki |latest |recent )?(?:photos?|tasveer(?:en)?) (?:dikhao|dekho|batao)$")?.let {
            return PhoneTools.listPhotos(ctx)
        }
        m("^(?:(\\d+) )?(?:latest |ye |yeh |purani )?(?:photos?|tasveer(?:en)?) delete karo$")?.let {
            val n = it.groupValues[1].toIntOrNull()?.coerceIn(1, 10) ?: 1
            return PhoneTools.askDelete(ctx, n)
        }
        m("^(?:ye |yeh |latest )?(?:photo|tasveer) (?:whatsapp|whats app) (?:par|pe) (?:bhejo|share karo)$")?.let {
            return PhoneTools.shareLatestToWhatsApp(ctx)
        }
        m("^(?:photo|tasveer) (?:lo|kheencho|khicho|click karo)$")?.let {
            return PhoneTools.openCameraForPhoto(ctx)
        }

        // ---- Media apps ----
        m("^youtube (?:pe|par) (.+?)(?: chalao| search karo)?$")?.let {
            val q = it.groupValues[1]
            openUri(ctx, "https://www.youtube.com/results?search_query=" + enc(q), "com.google.android.youtube")
            return "YouTube pe \"$q\" khol diya. Video tap karo, phir bolo 'aage' ya 'peeche'."
        }
        m("^spotify (?:pe|par) (.+?)(?: chalao| bajao)?$")?.let {
            val q = it.groupValues[1]
            openUri(ctx, "spotify:search:" + enc(q), "com.spotify.music")
            return "Spotify pe \"$q\" khol diya."
        }
        m("^(?:pause|rok do|ruko|play|chalao|chala do)$")?.let {
            if (svc == null) return NO_SERVICE
            if (svc.clickText("Pause") || svc.clickText("Play")) return "Ho gaya."
            mediaKey(ctx); return "Play/pause bheja."
        }
        m("^(?:10 second )?aage(?: 10 second)?$")?.let { return act(svc) { s -> s.doubleTapSide(true); true } }
        m("^(?:10 second )?peeche(?: 10 second)?$")?.let { return act(svc) { s -> s.doubleTapSide(false); true } }

        // ---- Phone control ----
        m("^(?:wapas|back)$")?.let { return act(svc) { s -> s.back(); true } }
        m("^(?:home|home jao)$")?.let { return act(svc) { s -> s.home(); true } }
        m("^recents?$")?.let { return act(svc) { s -> s.recents(); true } }
        m("^scroll (neeche|niche|upar)$")?.let {
            val fwd = it.groupValues[1] != "upar"
            return act(svc) { s -> s.scroll(fwd) }
        }
        m("^(?:type karo|likho) (.+)$")?.let {
            val txt = it.groupValues[1]
            return act(svc) { s -> s.typeText(txt) }
        }
        m("^(?:notification|notifications) (?:kholo|khol do)$")?.let { return act(svc) { s -> s.notifications(); true } }
        m("^(.+?) (?:kholo|khol do|open karo)$")?.let { return openApp(ctx, it.groupValues[1]) }

        // ---- Volume / torch / brightness / battery ----
        m("^volume (badhao|up)$")?.let { volume(ctx, AudioManager.ADJUST_RAISE); return "Volume badha diya." }
        m("^volume (kam karo|down)$")?.let { volume(ctx, AudioManager.ADJUST_LOWER); return "Volume kam kar diya." }
        m("^torch (on|chalu karo|jalao)$")?.let { return Device.torch(ctx, true) }
        m("^torch (off|band karo|bujhao)$")?.let { return Device.torch(ctx, false) }
        m("^brightness (\\d+)")?.let { return Device.brightness(ctx, it.groupValues[1].toInt()) }
        m("^brightness full$")?.let { return Device.brightness(ctx, 100) }
        m("^battery(?: kitni hai)?$")?.let { return Device.battery(ctx) }

        // ---- Time / alarm / timer ----
        m("^(\\d+) minute ka timer$")?.let {
            val mins = it.groupValues[1].toInt()
            return try {
                ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, mins * 60)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS timer")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "$mins minute ka timer laga diya."
            } catch (e: Exception) { "Clock app mein timer set nahi hua." }
        }
        m("^(?:subah|raat|shaam|dopahar)? ?(\\d{1,2}) baje alarm(?: laga do| lagao)?$")?.let {
            var h = it.groupValues[1].toInt()
            val part = raw.lowercase()
            if ((part.contains("raat") || part.contains("shaam")) && h < 12) h += 12
            return Device.alarm(ctx, h, 0)
        }
        m("^(time kya|samay kya|time)$")?.let {
            return "Abhi " + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date())
        }
        m("^(aaj ki date|date kya|date)$")?.let {
            return SimpleDateFormat("dd MMMM yyyy, EEEE", Locale("hi", "IN")).format(Date())
        }

        // ---- Calls / SMS / WhatsApp ----
        m("^(.+?) ko call (?:karo|kar do|laga do)$|^call (.+)$")?.let {
            val name = it.groupValues[1].ifEmpty { it.groupValues[2] }
            val c = Device.findContact(ctx, name) ?: return "$name contacts mein nahi mila (ya contacts permission nahi hai)."
            Pending.set("call") { Device.call(ctx, name) }
            return "${c.first} ko call karun? 'haan' ya 'nahi' bolo."
        }
        m("^(.+?) ko sms (?:bhejo|bhej do) (.+)$")?.let {
            return confirmSend(ctx, it.groupValues[1], it.groupValues[2], false)
        }
        m("^(.+?) ko whatsapp (?:message )?(?:bhejo|bhej do) (.+)$")?.let {
            return confirmSend(ctx, it.groupValues[1], it.groupValues[2], true)
        }
        m("^sms padho$")?.let { return Device.readSms(ctx) }
        m("^clipboard(?: padho)?$")?.let { return Device.clipboard(ctx) }

        // ---- Mausam ----
        m("^mausam(?: kaisa hai| kaisa)?(?: (.+))?$")?.let {
            val city = it.groupValues[1].ifEmpty { "Delhi" }
            return Device.weather(city)
        }

        // ---- Yaad / notes ----
        m("^yaad rakho (.+)$")?.let { Memory.addFact(ctx, it.groupValues[1]); return "Theek hai, yaad rakh liya." }
        m("^kya yaad hai$")?.let {
            val f = Memory.facts(ctx)
            return if (f.isEmpty()) "Abhi kuch yaad nahi hai." else f.joinToString("\n") { "• $it" }
        }
        m("^sab bhool jao$")?.let { Memory.clearFacts(ctx); return "Ho gaya, sab bhool gaya." }
        m("^note karo (.+)$")?.let { Memory.addNote(ctx, it.groupValues[1]); return "Note kar liya." }
        m("^mere notes$")?.let {
            val n = Memory.notes(ctx)
            return if (n.isEmpty()) "Koi note nahi hai." else n.joinToString("\n") { "• $it" }
        }

        // ---- Mood khud badalna ----
        m("^mood badlo$")?.let {
            Persona.mood = Mood.values().random()
            return "Lo, mood ab ${Persona.mood.name.lowercase()} ${Persona.mood.emoji}"
        }
        return null
    }

    private fun gKey(ctx: Context): String? = SecurePrefs.geminiKey(ctx)

    private fun syncBanter(ctx: Context) {
        Persona.banter = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("banter", true)
    }

    private fun openWeb(ctx: Context, url: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    /** "200 word", "50 shabd", "lamba/bahut lamba/chhota" se lambai nikalta hai. Idea se lambai wala hissa alag karta hai. */
    fun parseLength(spec: String): Pair<String, Int> {
        val n = Regex("(\\d{1,5})\\s*(?:word|words|shabd)", RegexOption.IGNORE_CASE).find(spec)
        if (n != null) {
            val words = n.groupValues[1].toInt().coerceIn(20, 3000)
            return spec.replace(n.value, "").replace(Regex("\\s+(?:ka|ki|ke|tak)\\s*$"), "").trim() to words
        }
        val s = spec.lowercase()
        val w = when {
            Regex("bahut lamba|very long|detailed|vistaar").containsMatchIn(s) -> 600
            Regex("lamba|long").containsMatchIn(s) -> 300
            Regex("chhota|short|chota").containsMatchIn(s) -> 60
            else -> 150
        }
        return spec.replace(Regex("(?i)bahut lamba|very long|lamba|long|chhota|chota|short|detailed"), "").trim() to w
    }

    private fun makePrompt(ctx: Context, spec: String, video: Boolean): String {
        val key = gKey(ctx) ?: return "Prompt banane ke liye Gemini key chahiye (Settings ⚙)."
        val (idea, words) = parseLength(spec)
        if (idea.isBlank()) return "Kis cheez ka prompt banana hai? Jaise: prompt banao ek cyberpunk shehar 200 word."
        val kind = if (video)
            "AI VIDEO generator ke liye scene-by-scene prompt: subject, setting, camera angle/movement, lighting, mood, style, har scene ka seconds, sound/music, aur negative cues."
        else
            "AI image generator ya chatbot ke liye prompt: subject, setting, style, lighting, colors, composition, mood, quality keywords, aur negative cues (jahan lage)."
        return try {
            val out = Gemini.text(ctx,
                "Tum ek expert prompt engineer ho. Neeche ke idea par $kind\n" +
                "Lambai: lagbhag $words words (ye zaroori hai). Prompt English mein likho jab tak idea kisi aur bhasha ki maang na kare. " +
                "SIRF prompt do, koi intro, samjhaana ya markdown fence nahi.\nIdea: $idea")
                .replace(Regex("^```\\w*\\n?|```$"), "").trim()
            LastPrompt.set(ctx, out)
            out + "\n\n(Lagbhag $words words ka prompt. Image ke liye bolo: 'is prompt se image banao'.)"
        } catch (e: Exception) { "Prompt nahi bana: ${e.message}" }
    }

    /** Roman Hinglish text ko saaf Hindi (Devanagari) mein badalta hai, taaki Hindi awaaz ekdam saaf bole. */
    fun toDevanagari(ctx: Context, text: String): String? {
        val key = gKey(ctx) ?: return null
        return try {
            val out = Gemini.text(ctx,
                "Neeche ka text Roman (Hinglish) mein hai. Use saaf, aasaan Hindi mein Devanagari lipi mein likho, arth bilkul wahi rahe. " +
                "Emoji hata do. Sirf badla hua text do, aur kuch nahi.\n\n" + text)
            out.trim().ifBlank { null }
        } catch (e: Exception) { null }
    }

    private fun makeFile(ctx: Context, kind: String, topic: String): String {
        val key = gKey(ctx) ?: return "File banane ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            when (kind) {
                "pdf" -> {
                    val body = Gemini.text(ctx, "Is topic par saaf, achha content likho (headings aur points ke saath). Sirf content do, koi intro ya mood tag nahi. Topic: $topic")
                    "PDF bana di: " + FileMaker.pdf(ctx, topic, body).absolutePath
                }
                "docx", "word" -> {
                    val body = Gemini.text(ctx, "Is topic par Word document ka content likho, paragraphs mein. Sirf content do. Topic: $topic")
                    "Word file bana di: " + FileMaker.docx(ctx, topic, body).absolutePath
                }
                else -> {
                    val csv = Gemini.text(ctx, "Is topic par spreadsheet ke liye data do: pehli line header, har line comma-separated. Koi markdown ya code block nahi. Topic: $topic")
                        .replace("```", "").trim()
                    "Excel bana diya: " + FileMaker.xlsx(ctx, topic, csv).absolutePath
                }
            }
        } catch (e: Exception) { "File nahi bani: ${e.message}" }
    }


    private fun githubSearch(q: String): String = try {
        val u = java.net.URL("https://api.github.com/search/repositories?per_page=5&sort=stars&q=" + enc(q))
        val c = u.openConnection() as java.net.HttpURLConnection
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "JarvisApp")
        c.connectTimeout = 15000; c.readTimeout = 20000
        if (c.responseCode !in 200..299) "GitHub ne jawab nahi diya (${c.responseCode}). Thodi der baad try karo."
        else {
            val items = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("items")
            if (items.length() == 0) "Kuch nahi mila."
            else (0 until items.length()).joinToString("\n") { i ->
                val r = items.getJSONObject(i)
                "• ${r.getString("full_name")} ★${r.getInt("stargazers_count")} — ${r.optString("description", "").take(80)}"
            } + "\nClone ke liye: github clone owner/repo"
        }
    } catch (e: Exception) { "GitHub search nahi hua: ${e.message}" }

    private fun makeAnyFile(ctx: Context, name: String, topic: String): String {
        val key = gKey(ctx) ?: return "File ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val body = Gemini.text(ctx, "File '$safeName' ka poora content likho, topic: $topic. Sirf file ka content do, koi markdown code fence ya samjhaana nahi.")
                .replace(Regex("^```\\w*\\n?|```$"), "").trim()
            val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, safeName)
            f.writeText(body)
            "File bana di: ${f.absolutePath}"
        } catch (e: Exception) { "File nahi bani: ${e.message}" }
    }


    private fun makeApp(ctx: Context, idea: String): String {
        val key = gKey(ctx) ?: return "App ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            val raw = Gemini.text(ctx, "Ek ORIGINAL chhota Android app project banao (Kotlin, Gradle Kotlin DSL, minSdk 26, koi external library nahi). Idea: $idea. " +
                "Kisi doosre app ka code/naam/art copy mat karo. Ye files do: settings.gradle.kts, build.gradle.kts, app/build.gradle.kts, app/src/main/AndroidManifest.xml, " +
                "app/src/main/java/com/example/myapp/MainActivity.kt, app/src/main/res/values/strings.xml. " +
                "Format SIRF ye: har file pehle '=== path ===' line, phir content. Koi samjhaana ya code fence nahi.")
            val parts = Regex("(?m)^=== (.+?) ===\\s*\\n").split(raw).drop(1)
            val names = Regex("(?m)^=== (.+?) ===\\s*$").findAll(raw).map { it.groupValues[1].trim() }.toList()
            if (names.isEmpty() || names.size != parts.size) return "App ke files sahi format mein nahi aaye, dobara try karo."
            val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "app_${System.currentTimeMillis()}.zip")
            java.util.zip.ZipOutputStream(f.outputStream()).use { z ->
                names.forEachIndexed { i, n ->
                    if (n.contains("..") || n.startsWith("/")) return@forEachIndexed
                    z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(parts[i].trim().toByteArray()); z.closeEntry()
                }
            }
            "App project bana diya (zip): ${f.absolutePath}\nAPK ke liye: zip extract karo, Android Studio/Android Code Studio mein kholo, Build > Build APK. Pehli build par error aaye to message bhejna."
        } catch (e: Exception) { "App nahi bana: ${e.message}" }
    }

    private fun makeGame(ctx: Context, idea: String): String {
        val key = gKey(ctx) ?: return "Game ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            val html = Gemini.text(ctx, "Ek ORIGINAL single-file HTML5 game banao (HTML+CSS+JS ek hi file, touch controls, mobile screen ke liye). Idea: $idea. Kisi ka naam, art ya code copy mat karo; sirf gameplay ka idea lo. Sirf HTML do, koi samjhaana ya code fence nahi.")
                .replace(Regex("^```\\w*\\n?|```$"), "").trim()
            val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "game_${System.currentTimeMillis()}.html")
            f.writeText(html)
            try {
                val uri = androidx.core.content.FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "text/html")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Exception) { }
            "Game bana di: ${f.absolutePath}\n(Browser mein khulegi. APK chahiye to ye file Android Studio/WebView project mein daalni hogi.)"
        } catch (e: Exception) { "Game nahi bani: ${e.message}" }
    }

    private fun makeImage(ctx: Context, prompt: String): String {
        val key = gKey(ctx) ?: return "Image ke liye Gemini key chahiye (Settings ⚙)."
        return try {
            val bytes = Gemini.image(ctx, prompt)
            val f = java.io.File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "img_${System.currentTimeMillis()}.png")
            f.writeBytes(bytes)
            "Image bana di: ${f.absolutePath}"
        } catch (e: Exception) { "Image nahi bani: ${e.message}" }
    }

    private fun confirmSend(ctx: Context, who: String, msg: String, wa: Boolean): String {
        val c = Device.findContact(ctx, who) ?: return "$who contacts mein nahi mila."
        val label = if (wa) "WhatsApp" else "SMS"
        Pending.set(label) { if (wa) Device.whatsapp(ctx, who, msg) else Device.sms(ctx, who, msg) }
        return "${c.first} ko $label: \"$msg\" bhejun? 'haan' ya 'nahi' bolo."
    }

    private fun factsStr(ctx: Context): String = Memory.facts(ctx).joinToString("; ").ifEmpty { "kuch nahi" }

    /** Naya notification aaya: kisne bheja, kya bola, opinion, reply options. */
    fun analyzeMessage(ctx: Context, app: String, sender: String, msg: String): Reply {
        syncBanter(ctx)
        val key = gKey(ctx) ?: return Reply("$app pe $sender ka message aaya: $msg. Opinion ke liye Gemini key daalo.", Mood.CHILL)
        return try {
            val prompt = Persona.systemPrompt(factsStr(ctx)) + "\n\nAb ye notification aaya hai:\nApp: $app\nKisne bheja: $sender\nMessage: $msg\n\n" +
                "Hinglish mein, dost ki tarah, is format mein jawab do: (1) kisne bheja aur kya bola, ek line mein. (2) tera opinion, emotion ke saath. (3) reply ke 2 chhote options. Pehli line mood tag. Kuch bhejne ka faisla mat karo, bas suggest karo."
            val (mood, text) = Persona.parse(Gemini.text(ctx, prompt))
            mood?.let { Persona.mood = it }
            Reply("$app pe $sender ka message: $text", mood ?: Persona.mood)
        } catch (e: Exception) {
            Reply("$app pe $sender ka message: $msg", Mood.CHILL)
        }
    }

    /** Photo ko dekh ke jawab. */
    fun vision(ctx: Context, jpg: ByteArray, q: String): Reply {
        val key = gKey(ctx) ?: return Reply("Photo dekhne ke liye Gemini key chahiye (Settings ⚙).", Mood.SAD)
        return try {
            syncBanter(ctx)
            val prompt = Persona.systemPrompt(factsStr(ctx), Lang.forcedName(ctx)) +
                "\n\nUser ne ye photo bheji aur pucha: \"$q\".\n" +
                "Pehle mood tag, phir dost wale andaaz mein EKDAM SAAF aur achhe se samjhao:\n" +
                "1) Photo mein kya hai (cheez/jaanwar/jagah/text/sawal), seedhi baat mein.\n" +
                "2) Wo kya hai aur kis kaam aati hai / kaise kaam karti hai, aasaan shabdon mein.\n" +
                "3) Ek ya do asaan EXAMPLE (jaise roz ki zindagi se).\n" +
                "4) Agar photo mein koi sawal, maths, homework ya code hai to step-by-step hal karo, phir answer.\n" +
                "5) Agar saaman hai to use kaise karein aur kya dhyan rakhein (safety). Price sirf andaaza bol sakte ho, pakka nahi.\n" +
                "Jo dikh raha hai wahi bolo; dhundhla ya adhura ho to saaf bolo ki kya pakka nahi, andaaza mat bhidao. User ke sawal ka seedha jawab sabse upar rakho."
            val (mood, text) = Persona.parse(Gemini.vision(ctx, prompt, jpg))
            mood?.let { Persona.mood = it }
            Reply(text, mood ?: Persona.mood)
        } catch (e: Exception) {
            Reply("Photo samajh nahi aayi: ${e.message}", Mood.SAD)
        }
    }

    private fun act(svc: JarvisAccessibilityService?, block: (JarvisAccessibilityService) -> Boolean): String {
        if (svc == null) return NO_SERVICE
        return if (block(svc)) "Ho gaya." else "Ye kaam abhi nahi hua."
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun openUri(ctx: Context, uri: String, pkg: String) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i.setPackage(pkg)) }
        catch (e: Exception) { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val pkg = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true)
        }?.packageName ?: return "$name naam ka app nahi mila."
        val i = pm.getLaunchIntentForPackage(pkg) ?: return "$name khul nahi sakta."
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "$name khol diya."
    }

    private fun volume(ctx: Context, dir: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
    }

    private fun mediaKey(ctx: Context) {
        ctx.sendOrderedBroadcast(Intent(Intent.ACTION_MEDIA_BUTTON)
            .putExtra(Intent.EXTRA_KEY_EVENT, KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)), null)
    }

    /** Gemini sirf tab jab local/device se kuch na bane. History + facts + mood saath bheje jaate hain. */
    private fun askGemini(ctx: Context, q: String): Reply {
        val key = SecurePrefs.geminiKey(ctx) ?: ""
        ensureHistory(ctx)
        if (key.isEmpty()) return Reply("Dost, Gemini key nahi daali. Settings (⚙) mein daal de, tab tak chhoti baatein aur phone commands chalenge.", Mood.SAD)

        val facts = Memory.facts(ctx).joinToString("; ").ifEmpty { "kuch nahi" }
        history.add("user" to q)
        return try {
            val contents = JSONArray()
            history.takeLast(12).forEach { (role, text) ->
                contents.put(JSONObject()
                    .put("role", if (role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", Persona.systemPrompt(facts, Lang.forcedName(ctx))))))
                .put("contents", contents)
            val (mood, text) = Persona.parse(Gemini.textFrom(Gemini.runWithFallback(ctx, body)))
            Lang.pref(ctx).let { if (it != "auto") Persona.lang = it }
            history.add("model" to text)
            trimHistory()
            saveHistory(ctx)
            if (mood != null) Persona.mood = mood
            Reply(text, mood ?: Persona.mood)
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            Reply("Net ya key mein dikkat hai: ${e.message}", Mood.SAD)
        }
    }

    private fun post(key: String, body: JSONObject): String = Gemini.textFrom(Gemini.run(key, body))

    private var historyLoaded = false

    private fun ensureHistory(ctx: Context) {
        if (historyLoaded) return
        historyLoaded = true
        val raw = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("chat_history", "[]") ?: "[]"
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                history.add(o.getString("role") to o.getString("text"))
            }
        } catch (_: Exception) { }
    }

    private fun trimHistory() {
        while (history.size > 40) history.removeAt(0)
    }

    private fun saveHistory(ctx: Context) {
        val a = JSONArray()
        history.forEach { a.put(JSONObject().put("role", it.first).put("text", it.second)) }
        ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString("chat_history", a.toString()).apply()
    }
    // Conservative path allow-list prevents shell metacharacters in spoken paths.
    private fun safeWorkspacePath(path: String): Boolean =
        path.isNotBlank() && path.length <= 240 && path.matches(Regex("[A-Za-z0-9_./~ -]+")) &&
            !path.split('/').contains("..")

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
}


/** Jo kaam user ki 'haan' ka wait kar raha hai (call / SMS / WhatsApp). */
object Pending {
    @Volatile var run: (() -> String)? = null
    fun set(label: String, action: () -> String) { run = action }
    fun clear() { run = null }
}

/** Aakhri bana hua AI prompt (taaki 'is prompt se image banao' chal sake). */
object LastPrompt {
    fun set(ctx: Context, p: String) { ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString("last_prompt", p).apply() }
    fun get(ctx: Context): String? = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("last_prompt", null)?.takeIf { it.isNotBlank() }


}
