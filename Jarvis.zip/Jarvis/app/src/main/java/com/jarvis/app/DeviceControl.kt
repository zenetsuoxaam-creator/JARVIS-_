package com.jarvis.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothClass
import android.content.Context
import android.os.Build
import java.net.URLEncoder

/** URL banane wale pure helpers (unit test ho sakte hain). */
object DeviceUrls {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun youtubeSearch(q: String) = "https://www.youtube.com/results?search_query=" + enc(q)

    /** Google "I'm Feeling Lucky": pehla result seedha khulta hai (best-effort). */
    fun youtubeLucky(q: String) = "https://www.google.com/search?btnI=1&q=" + enc("$q site:youtube.com")

    fun googleSearch(q: String) = "https://www.google.com/search?q=" + enc(q)

    /** Free + legal sources par hi movie dhoondhta hai (YouTube, Tubi, Pluto TV, Internet Archive). */
    fun freeMovies(q: String) = googleSearch("$q full movie watch free (site:youtube.com OR site:tubitv.com OR site:pluto.tv OR site:archive.org)")

    /** Anime: legal platforms (Crunchyroll, YouTube officials, Tubi). */
    fun anime(q: String) = googleSearch("$q anime episode watch online (site:crunchyroll.com OR site:youtube.com OR site:tubitv.com)")

    fun playStore(q: String) = "https://play.google.com/store/search?c=apps&q=" + enc(q)

    fun normalize(u: String): String {
        val t = u.trim().trimEnd('.', ',')
        return if (Regex("^https?://", RegexOption.IGNORE_CASE).containsMatchIn(t)) t else "https://$t"
    }
}

/**
 * Bluetooth HID (phone = keyboard + mouse + media remote) ke upar chalne wala "connected device control".
 *
 * Rules:
 *  - Pehle user ki permission (haan) zaroori hai; permission SIRF usi device ke liye hai jiske liye di gayi.
 *  - Device disconnect ho ya doosra device juda ho to permission khatam. 30 minute kuch na karo to bhi khatam.
 *  - "device control band karo" se turant wapas.
 *  - Download ke liye har baar alag 'haan' maanga jaata hai.
 *  - Jarvis wahi keys bhejta hai jo ek asli keyboard bhejta; kuch bhi chhupa ke nahi hota, aur har step ka text chat mein aata hai.
 */
@SuppressLint("NewApi")
object DeviceControl {
    enum class Kind(val label: String) {
        WINDOWS("Windows computer"), MAC("Mac"), LINUX("Linux computer (browser khula hona chahiye)"),
        ANDROID("Android phone/tablet"), TV("TV")
    }

    private const val TTL = 30 * 60 * 1000L
    private var okAddr: String? = null
    private var okAt = 0L

    private const val CTRL = 1
    private const val GUI = 8
    private const val K_ENTER = 0x28
    private const val K_ESC = 0x29
    private const val K_SPACE = 0x2C
    private const val K_B = 0x05
    private const val K_F = 0x09
    private const val K_J = 0x0D
    private const val K_L = 0x0F
    private const val K_R = 0x15
    private const val K_T = 0x17

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private fun pause(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) { } }

    private fun kind(ctx: Context): Kind {
        prefs(ctx).getString("host_os_" + BtHid.hostAddress(), null)?.let { s ->
            Kind.values().firstOrNull { it.name == s }?.let { return it }
        }
        return when (BtHid.hostMajorClass()) {
            BluetoothClass.Device.Major.PHONE -> Kind.ANDROID
            BluetoothClass.Device.Major.AUDIO_VIDEO -> Kind.TV
            else -> Kind.WINDOWS
        }
    }

    private fun revoke() { okAddr = null; okAt = 0 }

    /** null = sab theek, warna user ko dikhane wala message. */
    private fun guard(): String? {
        if (!BtHid.connected)
            return "Koi device connected nahi hai. Pehle us device se pair karo, phir 'bluetooth remote kholo' bolo aur device chuno " +
                   "(ya \"<device ka naam> se connect karo\")."
        val now = System.currentTimeMillis()
        if (okAddr == null || okAddr != BtHid.hostAddress() || now - okAt > TTL) {
            revoke()
            return "Is device ko control karne ki permission nahi hai. Bolo: \"jo device connected hai use control karo\"."
        }
        okAt = now
        return null
    }

    private fun openUrl(k: Kind, url: String): Boolean {
        when (k) {
            Kind.WINDOWS -> { BtHid.key(K_R, GUI); pause(900); BtHid.typeText(url); pause(200); BtHid.key(K_ENTER) }
            Kind.MAC -> {
                BtHid.key(K_SPACE, GUI); pause(700); BtHid.typeText("safari"); pause(500); BtHid.key(K_ENTER); pause(2000)
                BtHid.key(K_L, GUI); pause(300); BtHid.typeText(url); pause(200); BtHid.key(K_ENTER)
            }
            Kind.LINUX -> { BtHid.key(K_T, CTRL); pause(600); BtHid.typeText(url); pause(200); BtHid.key(K_ENTER) }
            Kind.ANDROID -> {
                BtHid.media(6); pause(900)          // Home
                BtHid.key(K_B, GUI); pause(2500)    // Android shortcut: Meta+B = browser
                BtHid.key(K_L, CTRL); pause(400); BtHid.typeText(url); pause(200); BtHid.key(K_ENTER)
            }
            Kind.TV -> return false
        }
        return true
    }

    private fun tvNote() =
        "TV par browser/URL kholne ka koi bharosemand tareeka keyboard se nahi hota. TV ke liye ye bolo: " +
        "\"tv pe home\", \"tv pe neeche\", \"tv pe ok\", \"tv pe type <text>\" (YouTube ka search box khula ho to), \"tv pe play\", \"tv pe volume badhao\"."

    private fun go(ctx: Context, url: String, said: String): String {
        val k = kind(ctx)
        if (!openUrl(k, url)) return tvNote()
        return "$said\n(${k.label} par bheja: $url)"
    }

    fun handle(ctx: Context, raw: String): String? {
        val t = raw.trim()
        fun m(p: String) = Regex(p, RegexOption.IGNORE_CASE).find(t)
        val dev = "(?:device|divice|tv|computer|laptop|pc|system)"

        // ---- Band karo ----
        if (m("^(?:$dev )?control (?:band karo|band kar do|off|stop)$|^$dev control hatao$") != null) {
            revoke()
            return "Device control band. Permission wapas le li; dobara chahiye to phir se poochhunga."
        }

        // ---- Permission maangna ----
        if (m("^(?!.*\\bband\\b).*\\b$dev\\b.*control (?:karo|kar do|kar lo)$") != null) {
            if (Build.VERSION.SDK_INT < 28) return "Device control ke liye Android 9 ya naya phone chahiye."
            if (!BtHid.registered) {
                BtHid.start(ctx)
                return "Bluetooth remote taiyaar ho raha hai. 5 second baad dobara bolo.\n" +
                       "(USB cable se TV/computer ko control karna Android app se nahi hota. Bluetooth se hota hai: pehle device ko phone se pair karo.)"
            }
            if (!BtHid.connected) return guard()
            val name = BtHid.hostName() ?: "ye device"
            val k = kind(ctx)
            val addr = BtHid.hostAddress()
            Pending.set("device") {
                okAddr = addr; okAt = System.currentTimeMillis()
                "Permission mil gayi: $name. Ab bolo, jaise \"device pe youtube arijit singh chalao\", \"device pe google python tutorial\", " +
                "\"device pe anime naruto lagao\", \"device pe play store pubg install karo\", \"device pe download <link>\".\n" +
                "Band karne ke liye: \"device control band karo\". Disconnect hote hi permission khatam ho jaati hai."
            }
            return "\"$name\" (mujhe ye ${k.label} lag raha hai) ko control karne ki permission doge?\n" +
                   "Main uspe keyboard/mouse ki tarah search, link kholna, download aur media control kar sakta hoon. " +
                   "Galat type ho to pehle bolo: \"ye mac hai\" / \"ye android hai\" / \"ye tv hai\" / \"ye linux hai\".\n'haan' ya 'nahi' bolo."
        }

        // ---- Device ka type sahi karna ----
        m("^(?:ye|yeh|device|computer|laptop|pc) (windows|mac|macbook|linux|android|tv) (?:hai|he)$")?.let {
            if (Build.VERSION.SDK_INT < 28 || !BtHid.connected) return null
            val k = when (it.groupValues[1].lowercase()) {
                "mac", "macbook" -> Kind.MAC
                "linux" -> Kind.LINUX
                "android" -> Kind.ANDROID
                "tv" -> Kind.TV
                else -> Kind.WINDOWS
            }
            prefs(ctx).edit().putString("host_os_" + BtHid.hostAddress(), k.name).apply()
            return "Theek hai, ab se ise ${k.label} maanunga."
        }

        // ---- Naam se connect ----
        m("^(.+?) (?:se connect karo|se jud jao|ko connect karo)$")?.let {
            if (Build.VERSION.SDK_INT < 28) return null
            val n = BtHid.connectByName(it.groupValues[1].trim()) ?: return null
            return "$n se connect kar raha hoon. Us device par 'JARVIS Remote' allow/accept karo, phir bolo: \"jo device connected hai use control karo\"."
        }

        // ---- Asli commands: "<device> pe ..." ----
        val sub = m("^$dev (?:pe|par|mein|me) (.+)$")?.groupValues?.get(1)?.trim() ?: return null
        if (Build.VERSION.SDK_INT < 28) return "Device control ke liye Android 9 ya naya phone chahiye."
        guard()?.let { return it }
        fun s(p: String) = Regex(p, RegexOption.IGNORE_CASE).find(sub)

        // YouTube
        s("^youtube (?:kholo|khol do)$")?.let { return go(ctx, "https://www.youtube.com", "YouTube khol raha hoon.") }
        s("^youtube (?:pe |par )?(.+?)(?: (chalao|lagao|bajao|search karo|dikhao|dhoondo))?$")?.let {
            val q = it.groupValues[1].trim()
            val play = it.groupValues[2].lowercase() in listOf("chalao", "lagao", "bajao")
            return if (play) go(ctx, DeviceUrls.youtubeLucky(q), "\"$q\" ka pehla YouTube result chala raha hoon (best-effort; galat aaye to 'device pe youtube $q search karo' bolo).")
                   else go(ctx, DeviceUrls.youtubeSearch(q), "YouTube par \"$q\" search kar diya. Video chunne ke liye 'device pe ok' / 'device pe neeche' bolo.")
        }

        // Movies / anime / webstories: free + legal sources par (piracy sites nahi)
        s("^(movie|film|anime|webstory|web story|webseries|series|show|episode)s? (.+?) (?:lagao|chalao|dikhao|dekhna hai)$")?.let {
            val kindWord = it.groupValues[1].lowercase()
            val name = it.groupValues[2].trim()
            return when (kindWord) {
                "movie", "film" -> go(ctx, DeviceUrls.freeMovies(name), "\"$name\" ke free (legal) results khol diye: YouTube/Tubi/Pluto/Archive. Jo link chahiye uspe 'device pe ok' bolo.")
                "anime" -> go(ctx, DeviceUrls.anime(name), "\"$name\" anime ke legal results khol diye. Episode chun kar 'device pe ok' bolo.")
                else -> go(ctx, DeviceUrls.youtubeSearch("$name " + if (kindWord.startsWith("web")) "web story" else "episode"), "\"$name\" ke results YouTube par khol diye.")
            }
        }

        // Google
        s("^google (?:pe |par )?(.+?)(?: search karo| dhoondo)?$")?.let {
            val q = it.groupValues[1].trim()
            return go(ctx, DeviceUrls.googleSearch(q), "Google par \"$q\" search kar diya.")
        }

        // Link / website kholna
        s("^(https?://\\S+|(?:www\\.)?[\\w-]+(?:\\.[\\w-]+)+(?:/\\S*)?) (?:kholo|khol do|open karo)$")?.let {
            val u = DeviceUrls.normalize(it.groupValues[1])
            return go(ctx, u, "Link khol raha hoon.")
        }

        // Download (har baar alag permission)
        s("^download (https?://\\S+)$")?.let {
            val u = DeviceUrls.normalize(it.groupValues[1])
            Pending.set("download") {
                guard() ?: go(ctx, u, "Download link khol diya. Device ka browser download shuru karega; 'device pe downloads kholo' se list dikhegi.")
            }
            return "Device par ye link khol kar download karun?\n$u\nSirf bharosemand link ho tabhi. 'haan' ya 'nahi' bolo."
        }
        s("^downloads? (?:kholo|dikhao)$")?.let {
            val k = kind(ctx)
            return when (k) {
                Kind.WINDOWS, Kind.LINUX, Kind.ANDROID -> { BtHid.key(K_J, CTRL); "Browser ki downloads list khol di." }
                Kind.MAC -> { BtHid.key(K_L, GUI + 2); "Downloads list kholne ki koshish ki (Safari: Cmd+Shift+L)." }
                Kind.TV -> tvNote()
            }
        }
        s("^(.+?) download karo$")?.let {
            val q = it.groupValues[1].trim()
            return go(ctx, DeviceUrls.googleSearch("$q official download"), "\"$q\" ke official download ke results khol diye. Sahi site khud chuno.")
        }

        // Play Store: app/game
        s("^play ?store (?:pe |par |se )?(.+?)(?: (?:download|install))?(?: karo)?$")?.let {
            val q = it.groupValues[1].trim()
            val k = kind(ctx)
            val extra = if (k == Kind.WINDOWS || k == Kind.MAC || k == Kind.LINUX)
                "\nDhyan: computer par Play Store web se 'Install' dabaane par app aapke Google account ke phone/tablet par install hota hai, computer par nahi."
            else ""
            return go(ctx, DeviceUrls.playStore(q), "Play Store par \"$q\" khol diya. Install button aapko khud dabana hai ('device pe ok' se bhi dab sakta hai).") + extra
        }

        // Type / scroll
        s("^(?:type|likho) (.+)$")?.let { BtHid.typeText(it.groupValues[1]); return "Likh diya." }
        s("^scroll (neeche|niche|upar)$")?.let { BtHid.wheel(if (it.groupValues[1] == "upar") 5 else -5); return "Scroll kar diya." }

        // Remote keys
        s("^(up|upar|down|neeche|niche|left|right|ok|enter|select|back|wapas|esc|escape|home|play|pause|play pause|next|prev|previous|mute|volume badhao|volume kam karo|fullscreen)$")?.let {
            when (it.groupValues[1].lowercase()) {
                "up", "upar" -> BtHid.key(0x52)
                "down", "neeche", "niche" -> BtHid.key(0x51)
                "left" -> BtHid.key(0x50)
                "right" -> BtHid.key(0x4F)
                "ok", "enter", "select" -> BtHid.key(K_ENTER)
                "esc", "escape" -> BtHid.key(K_ESC)
                "back", "wapas" -> BtHid.media(7)
                "home" -> BtHid.media(6)
                "play", "pause", "play pause" -> BtHid.media(3)
                "next" -> BtHid.media(4)
                "prev", "previous" -> BtHid.media(5)
                "mute" -> BtHid.media(2)
                "volume badhao" -> BtHid.media(0)
                "volume kam karo" -> BtHid.media(1)
                "fullscreen" -> BtHid.key(K_F)
            }
            return "Ho gaya."
        }

        return "Ye device command samajh nahi aaya. Try karo: youtube <naam> chalao, google <kuch> , anime <naam> lagao, " +
               "play store <app> install karo, download <link>, <site.com> kholo, ok/neeche/play/fullscreen."
    }
}
