package com.jarvis.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

/** Explicit per-call consent UI. No call is answered unless Answer is tapped. */
class CallConsentActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var answered = false
    private val bg = Color.rgb(11, 11, 15)
    private val white = Color.rgb(238, 238, 242)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tts = TextToSpeech(this, this)
        if (intent?.action == Intent.ACTION_DIAL) showDialPad() else showIncomingCall()
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(36, 40, 36, 40)
        setBackgroundColor(bg)
    }

    private fun actionButton(label: String, color: Int, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        textSize = 18f
        setOnClickListener { action() }
    }

    private fun showIncomingCall() {
        val root = baseLayout()
        val call = JarvisInCallService.currentCall
        val number = call?.details?.handle?.schemeSpecificPart?.takeIf { it.isNotBlank() } ?: "Unknown caller"
        root.addView(TextView(this).apply {
            text = "JARVIS • Incoming call\n\n$number\n\nAnswer karne se pehle caller ko speaker par rakha jayega."
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(white)
        })
        root.addView(actionButton("Answer + Speaker ON", Color.rgb(30, 135, 75)) {
            val ok = JarvisInCallService.service?.answerWithSpeaker() == true
            if (ok) {
                answered = true
                Toast.makeText(this, "Call connected. Jarvis greeting bol raha hai.", Toast.LENGTH_SHORT).show()
                speakGreeting()
                showConnectedState(root)
            } else {
                Toast.makeText(this, "Call ab available nahi hai.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28 })
        root.addView(actionButton("Decline", Color.rgb(170, 35, 35)) {
            JarvisInCallService.service?.decline()
            finish()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })
        setContentView(root)
    }

    private fun showConnectedState(root: LinearLayout) {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "JARVIS • Call connected\n\nSpeaker ON\nGreeting played. Caller se baat karne ke liye phone ka microphone active rahega."
            textSize = 21f; gravity = Gravity.CENTER; setTextColor(white)
        })
        root.addView(actionButton("Call end karo", Color.rgb(170, 35, 35)) {
            JarvisInCallService.service?.hangUp()
            finish()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28 })
    }

    private fun speakGreeting() {
        if (ttsReady) tts?.speak(
            "Namaste, main Jarvis hoon. Aapki call Ayush ke phone par connected hai. Aap apna message bata sakte hain.",
            TextToSpeech.QUEUE_FLUSH, null, "jarvis_call_greeting"
        )
    }

    private fun showDialPad() {
        val root = baseLayout()
        root.addView(TextView(this).apply { text = "JARVIS Phone"; textSize = 25f; setTextColor(white) })
        val number = EditText(this).apply {
            hint = "Phone number"; textSize = 22f; setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            setText(intent?.data?.schemeSpecificPart ?: "")
        }
        root.addView(number, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24 })
        root.addView(actionButton("Call", Color.rgb(30, 135, 75)) {
            val value = number.text.toString().trim()
            if (value.isBlank()) {
                number.error = "Number daalo"
            } else {
                try {
                    val telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
                    telecom.placeCall(Uri.fromParts("tel", value, null), null)
                    finish()
                } catch (_: Exception) { Toast.makeText(this, "Call start nahi ho saki.", Toast.LENGTH_LONG).show() }
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale("hi", "IN")
            if (answered) speakGreeting()
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
