package com.jarvis.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiException(val code: Int, detail: String) : Exception(friendly(code, detail)) {
    companion object {
        fun friendly(code: Int, detail: String): String = when (code) {
            400 -> "Request galat hai (400)."
            401, 403 -> "Gemini key galat ya band hai. Settings (⚙) mein dobara daalo."
            404 -> "Model abhi uplabdh nahi (404)."
            429 -> "Gemini ki limit khatam ho gayi, thodi der baad try karo (429)."
            in 500..599 -> "Gemini server busy hai ($code). Thodi der baad try karo."
            else -> "Gemini error $code: ${detail.take(120)}"
        }
    }
}

/**
 * Ek hi jagah saare Gemini calls.
 *  - Key URL mein nahi, header (x-goog-api-key) mein jaati hai, taaki log/history mein na aaye.
 *  - Model band ho (404) to agla model try hota hai.
 *  - Non-2xx jawab par saaf error message milta hai.
 */
object Gemini {
    // Model IDs change over time. Discover currently available models from Google's API
    // instead of relying only on hard-coded IDs that may return 404.
    val TEXT_MODELS = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-flash-lite")
    const val IMAGE_MODEL = "gemini-2.0-flash-preview-image-generation"
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    @Volatile private var discoveredTextModels: List<String> = emptyList()
    @Volatile private var discoveredImageModels: List<String> = emptyList()
    @Volatile private var modelsLoadedAt: Long = 0L

    /** Fetch models actually exposed to this API key; API key stays in a header, not URL. */
    private fun discoverModels(key: String, force: Boolean = false): Pair<List<String>, List<String>> {
        val fresh = System.currentTimeMillis() - modelsLoadedAt < 10 * 60 * 1000L
        if (!force && fresh && discoveredTextModels.isNotEmpty())
            return discoveredTextModels to discoveredImageModels
        val conn = URL(BASE).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.setRequestProperty("x-goog-api-key", key)
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            val code = conn.responseCode
            if (code !in 200..299) throw GeminiException(code, conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty())
            val root = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val text = mutableListOf<String>()
            val image = mutableListOf<String>()
            val arr = root.optJSONArray("models") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val methods = item.optJSONArray("supportedGenerationMethods") ?: continue
                if ((0 until methods.length()).none { methods.optString(it) == "generateContent" }) continue
                val name = item.optString("name").removePrefix("models/")
                if (name.isBlank()) continue
                text.add(name)
                val label = (name + " " + item.optString("displayName")).lowercase()
                if (label.contains("image")) image.add(name)
            }
            // Prefer stable, generally available Flash models when the API lists them.
            val preferred = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-flash-lite")
            val sortedText = (preferred.filter { it in text } + text.filter { it !in preferred }).distinct()
            discoveredTextModels = sortedText
            discoveredImageModels = image.distinct()
            modelsLoadedAt = System.currentTimeMillis()
            return discoveredTextModels to discoveredImageModels
        } finally { conn.disconnect() }
    }

    private fun modelsForKey(key: String, requested: List<String>): List<String> {
        return try {
            val (text, image) = discoverModels(key)
            if (requested == listOf(IMAGE_MODEL)) {
                // Only try image-labelled models for image generation; never silently send an
                // image-output request to an ordinary text-only model.
                (image + requested.filter { it in text }).distinct().ifEmpty { requested }
            } else {
                (text + requested).distinct().ifEmpty { requested }
            }
        } catch (_: Exception) { requested }
    }

    private fun call(key: String, model: String, body: JSONObject): JSONObject {
        val conn = URL(BASE + model + ":generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GeminiException(code, text)
            return JSONObject(text)
        } finally {
            conn.disconnect()
        }
    }

    /** Automatic API-key failover for chat: only quota (429) marks a slot unavailable. */
    fun runWithFallback(ctx: android.content.Context, body: JSONObject, models: List<String> = TEXT_MODELS): JSONObject {
        val tried = mutableSetOf<String>()
        var last: Exception? = null
        repeat(6) {
            val key = SecurePrefs.geminiKey(ctx, tried) ?: throw (last ?: Exception("Abhi koi configured API key available nahi hai. Quota reset hone ya valid key add karne ke baad try karo."))
            tried.add(key)
            try { return run(key, body, models) }
            catch (e: GeminiException) {
                last = e
                when (e.code) {
                    429 -> SecurePrefs.markQuota(ctx, key) // quota full: skip until reset/cooldown
                    401, 403 -> SecurePrefs.markInvalid(ctx, key) // bad/revoked key: skip until user updates it
                    404 -> { /* model unavailable for this key: try another configured key */ }
                    in 500..599 -> { /* provider transient issue: try another key for this request */ }
                    else -> throw e // malformed request etc. will not improve by changing keys
                }
            }
        }
        throw last ?: Exception("Koi API key available nahi hai.")
    }

    /** Models ko ek-ek karke try karta hai. 404 ho to agla model; baaki errors seedha upar. */
    fun run(key: String, body: JSONObject, models: List<String> = TEXT_MODELS): JSONObject {
        var last: Exception? = null
        val candidates = modelsForKey(key, models)
        for (m in candidates) {
            try {
                return call(key, m, body)
            } catch (e: GeminiException) {
                if (e.code != 404) throw e
                last = e
                // A model may have been removed since discovery. Refresh once so the
                // next request uses the provider's current model catalogue.
                try { discoverModels(key, force = true) } catch (_: Exception) { }
            }
        }
        throw last ?: Exception("Gemini: koi model nahi chala")
    }

    fun text(ctx: android.content.Context, prompt: String): String =
        textFrom(runWithFallback(ctx, userParts(JSONObject().put("text", prompt))))

    fun vision(ctx: android.content.Context, prompt: String, jpg: ByteArray): String {
        val img = JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg")
            .put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)))
        return textFrom(runWithFallback(ctx, userParts(JSONObject().put("text", prompt), img)))
    }

    fun image(ctx: android.content.Context, prompt: String): ByteArray {
        val body = userParts(JSONObject().put("text", prompt)).put("generationConfig",
            JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val ps = parts(runWithFallback(ctx, body, listOf(IMAGE_MODEL)))
        for (i in 0 until ps.length()) { val part = ps.getJSONObject(i); if (part.has("inlineData"))
            return Base64.decode(part.getJSONObject("inlineData").getString("data"), Base64.DEFAULT) }
        throw Exception("Image nahi bani, dobara try karo")
    }

    fun editImage(ctx: android.content.Context, instruction: String, jpg: ByteArray): ByteArray {
        val img = JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg")
            .put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)))
        val body = userParts(JSONObject().put("text", instruction), img).put("generationConfig",
            JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val ps = parts(runWithFallback(ctx, body, listOf(IMAGE_MODEL)))
        for (i in 0 until ps.length()) { val part = ps.getJSONObject(i); if (part.has("inlineData"))
            return Base64.decode(part.getJSONObject("inlineData").getString("data"), Base64.DEFAULT) }
        throw Exception("Photo edit nahi ho saki")
    }

    private fun parts(j: JSONObject): JSONArray =
        j.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")

    /** Sirf text parts jodta hai (thinking parts chhod kar). */
    fun textFrom(j: JSONObject): String {
        val ps = parts(j)
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }

    private fun userParts(vararg p: JSONObject) = JSONObject().put(
        "contents", JSONArray().put(JSONObject().put("parts", JSONArray().apply { p.forEach { put(it) } }))
    )

    fun text(key: String, prompt: String): String =
        textFrom(run(key, userParts(JSONObject().put("text", prompt))))

    /** Photo + sawal. jpg = JPEG bytes. */
    fun vision(key: String, prompt: String, jpg: ByteArray): String {
        val img = JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg")
            .put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)))
        return textFrom(run(key, userParts(JSONObject().put("text", prompt), img)))
    }

    fun image(key: String, prompt: String): ByteArray {
        val body = userParts(JSONObject().put("text", prompt)).put("generationConfig",
            JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val ps = parts(run(key, body, listOf(IMAGE_MODEL)))
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("inlineData"))
                return Base64.decode(p.getJSONObject("inlineData").getString("data"), Base64.DEFAULT)
        }
        throw Exception("Image nahi bani, dobara try karo")
    }

    /** Photo edit: user ki photo + instruction -> nayi edited image (PNG/JPEG bytes). */
    fun editImage(key: String, instruction: String, jpg: ByteArray): ByteArray {
        val img = JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg")
            .put("data", Base64.encodeToString(jpg, Base64.NO_WRAP)))
        val body = userParts(JSONObject().put("text", instruction), img).put("generationConfig",
            JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val ps = parts(run(key, body, listOf(IMAGE_MODEL)))
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("inlineData"))
                return Base64.decode(p.getJSONObject("inlineData").getString("data"), Base64.DEFAULT)
        }
        throw Exception("Edit nahi hua, dobara try karo")
    }
}
