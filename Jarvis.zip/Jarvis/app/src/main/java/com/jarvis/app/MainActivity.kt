package com.jarvis.app

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors

private const val BG = "#0B0B0F"
private const val INK = "#ECECF1"
private const val MUTED = "#8B8B98"
private const val BORDER = "#2A2A33"
private const val CARD = "#16161C"
private const val CHIP = "#23232B"
private const val ACCENT = "#2878E8"
private const val ACCENT_ON = "#1557B0"
private val DARK_DIALOG = android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

/**
 * JARVIS HOME: Claude jaisa saaf screen.
 *  - Upar ☰ (settings) aur 👾 (monster kholne ka button)
 *  - Beech mein "Happy Monday, Ayush" + JARVIS logo (dark theme)
 *  - Neeche type box, [+] photo, [↑] send, aur 🎤 voice-talk (type box ke bagal mein)
 * Har jawab likha bhi jaata hai aur bola bhi jaata hai.
 */
class MainActivity : android.app.Activity(), TextToSpeech.OnInitListener {

    private lateinit var greet: LinearLayout
    private lateinit var greetText: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var voiceBtn: TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var voiceMode = false          // 🎤 voice-talk: baat khatam hone par phir sunta hai
    private var voiceErrors = 0
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }
    private val REQ_CAM = 7
    private var camQ = "Ye kya hai?"
    private val REQ_PICK = 8
    private val REQ_VID = 9
    private var pendingPhoto: ByteArray? = null   // gallery se chuni photo; agle message par kaam hoga
    private val warnedLang = HashSet<String>()
    private val asked = HashMap<String, Int>()
    private var setupDialog: AlertDialog? = null
    private var permPending = false

    /** Jo permissions app kholte hi maangi jaati hain (Termux wali alag, wo sirf Termux ho to kaam aati hai). */
    private val corePerms: List<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO); add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.SEND_SMS); add(Manifest.permission.READ_SMS)
        add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.CAMERA)
        add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_CONNECT); add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE) }
    }
    private val appPerms: List<String> = corePerms + "com.termux.permission.RUN_COMMAND"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor(BG)
        window.navigationBarColor = Color.parseColor(BG)
        tts = TextToSpeech(this, this)
        buildUi()
        val missing = appPerms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { permPending = true; requestPermissions(missing.toTypedArray(), 1) }
        if (prefs.getBoolean("usb_cast", false)) {
            try { UsbWatchService.start(this) } catch (_: Exception) { }
        }
        if (intent?.getBooleanExtra("voice", false) == true) ui.post { startListening() }
    }

    override fun onResume() {
        super.onResume()
        ui.postDelayed({ runSetup() }, 600)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permPending = false
        ui.postDelayed({ runSetup() }, 500)
    }

    private fun notifAccessOn(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    /** Jo special access Android sirf Settings screen se deta hai, unke liye ek-ek karke guide karta hai. */
    private fun nextSetupStep(): Triple<String, String, Intent>? {
        if (JarvisAccessibilityService.instance == null) return Triple("a11y",
            "Poore phone ko control karne ke liye ek baar ye ON karna zaroori hai.\n\nAccessibility screen khulegi: wahan 'JARVIS' chuno aur ON karo, phir wapas aao.",
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        if (!notifAccessOn()) return Triple("notif",
            "Notifications aur messages padhne ke liye 'JARVIS' ko Notification access do.",
            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        if (!Settings.System.canWrite(this)) return Triple("write",
            "Brightness jaise system settings badalne ke liye 'JARVIS' ko permission do.",
            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(Uri.parse("package:$packageName")))
        return null
    }

    private fun runSetup() {
        if (isFinishing || permPending || setupDialog?.isShowing == true) return
        val step = nextSetupStep() ?: return
        val n = asked[step.first] ?: 0
        if (n >= 2) return
        asked[step.first] = n + 1
        setupDialog = AlertDialog.Builder(this, DARK_DIALOG)
            .setTitle("JARVIS setup")
            .setMessage(step.second)
            .setPositiveButton("Allow karo") { _, _ ->
                try { startActivity(step.third) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            }
            .setNegativeButton("Baad mein", null)
            .show()
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        ttsReady = true
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { ui.post { afterSpeech() } }
            override fun onError(id: String?) { ui.post { afterSpeech() } }
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Float, stroke: Int): GradientDrawable =
        GradientDrawable().apply { setColor(fill); cornerRadius = radius; setStroke(dp(1), stroke) }

    private fun iconBtn(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 22f
        setTextColor(Color.parseColor(INK))
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { onClick() }
    }

    private fun circleBtn(label: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(fg)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
        setOnClickListener { onClick() }
    }

    private fun greetingText(): String {
        val days = arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        val day = days[Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1]
        val name = prefs.getString("name", "Ayush")?.takeIf { it.isNotBlank() } ?: "Ayush"
        return "Happy $day, $name"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor(BG))
        }

        // ---- upar ki bar: ☰ ... 👾 ----
        val top = FrameLayout(this).apply { setPadding(dp(12), dp(14), dp(12), dp(4)) }
        top.addView(iconBtn("☰") { showSettings() },
            FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        top.addView(iconBtn("👾") { startActivity(Intent(this, MonsterActivity::class.java)) },
            FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- beech ka hissa: greeting ya chat ----
        val middle = FrameLayout(this)
        greet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(JarvisLogoView(this@MainActivity),
                LinearLayout.LayoutParams(dp(84), dp(84)).apply { bottomMargin = dp(22) })
            greetText = TextView(this@MainActivity).apply {
                text = greetingText()
                textSize = 26f
                gravity = Gravity.CENTER
                typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
                setTextColor(Color.parseColor(INK))
            }
            addView(greetText)
        }
        middle.addView(greet, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))

        chat = TextView(this).apply {
            setTextColor(Color.parseColor(INK))
            textSize = 15f
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        chatScroll = ScrollView(this).apply {
            visibility = View.GONE
            addView(chat)
        }
        middle.addView(chatScroll, FrameLayout.LayoutParams(-1, -1))
        root.addView(middle, LinearLayout.LayoutParams(-1, 0, 1f))

        status = TextView(this).apply {
            setTextColor(Color.parseColor(MUTED))
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(4))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))

        // ---- neeche ka input card (Claude jaisa) ----
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor(CARD), dp(28).toFloat(), Color.parseColor(BORDER))
            setPadding(dp(16), dp(12), dp(10), dp(10))
        }
        input = EditText(this).apply {
            hint = "JARVIS se baat karo..."
            setHintTextColor(Color.parseColor(MUTED))
            setTextColor(Color.parseColor(INK))
            textSize = 16f
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
            }
        }
        card.addView(input, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        row.addView(circleBtn("+", Color.parseColor(CHIP), Color.parseColor(INK)) { openGallery() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(circleBtn("↑", Color.parseColor(CHIP), Color.parseColor(INK)) { sendTyped() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        voiceBtn = circleBtn("🎤", Color.parseColor(ACCENT), Color.WHITE) { toggleVoiceMode() }
        row.addView(voiceBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(10) })
        card.addView(row, LinearLayout.LayoutParams(-1, -2))

        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(6), dp(14), dp(16)) })
        setContentView(root)
    }

    /** Pehla message aate hi greeting hat kar chat dikhti hai. */
    private fun addChat(s: String) {
        greet.visibility = View.GONE
        chatScroll.visibility = View.VISIBLE
        chat.append(s + "\n\n")
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setStatus(s: String) { status.text = s }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isNotEmpty()) { input.setText(""); handle(t) }
    }

    /** Jawab bolta hai: pehle text saaf karta hai, Hindi ke liye Roman Hinglish ko Devanagari mein badalta hai. */
    private fun say(t: String) {
        if (!ttsReady) { afterSpeech(); return }
        val lang = Lang.speakLang(this)
        val plain = Lang.cleanForSpeech(t)
        if (plain.isEmpty()) { afterSpeech(); return }
        MonsterActivity.instance?.pushState("speaking", plain)
        setStatus("Bol raha hoon…")
        if (lang.startsWith("hi") && Lang.isRoman(plain) && plain.length < 500) {
            io.execute {
                val dev = CommandRouter.toDevanagari(this, plain)
                ui.post { speakNow(dev ?: plain, lang) }
            }
        } else speakNow(plain, lang)
    }

    private fun speakNow(text: String, lang: String) {
        val loc = Lang.locale(lang)
        val r = tts.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (warnedLang.add(lang))
                addChat("${loc.displayLanguage} ki awaaz phone mein nahi hai. Phone Settings > Text-to-speech mein ${loc.displayLanguage} voice data install karo.")
            tts.setLanguage(Locale("en", "IN"))
        } else {
            try {
                val all = tts.voices?.filter { it.locale.language == loc.language }.orEmpty()
                val best = all.filter { !it.isNetworkConnectionRequired }.maxByOrNull { it.quality }
                    ?: all.maxByOrNull { it.quality }
                if (best != null) tts.voice = best
            } catch (_: Exception) { }
        }
        val m = Persona.mood
        tts.setPitch(when (m) { Mood.HAPPY, Mood.EXCITED -> 1.08f; Mood.SAD, Mood.TIRED -> 0.92f; else -> 1.0f })
        tts.setSpeechRate(when (m) { Mood.EXCITED, Mood.ANGRY -> 1.02f; Mood.TIRED, Mood.SAD -> 0.88f; else -> 0.94f })
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    /** Bolna khatam hone ke baad: voice-talk ON ho to phir sunna shuru. */
    private fun afterSpeech() {
        MonsterActivity.instance?.pushState("idle")
        setStatus("")
        if (voiceMode) startListening()
    }

    private fun camFile() = File(getExternalFilesDir(null) ?: filesDir, "cam.jpg")

    private fun openCamera(q: String) {
        camQ = q
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", camFile())
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, uri)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION), REQ_CAM)
    }

    /** + dabane par gallery khulti hai (camera nahi). */
    private fun openGallery() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        try { startActivityForResult(Intent.createChooser(i, "Photo chuno"), REQ_PICK) }
        catch (e: Exception) { setStatus("Gallery nahi khul paayi") }
    }

    /** Badi photo ko 1600px tak chhota karke JPEG bytes deta hai (API data kam lagta hai). */
    private fun loadScaled(uri: Uri): ByteArray? = try {
        val bmp = contentResolver.openInputStream(uri)!!.use { android.graphics.BitmapFactory.decodeStream(it) }
        val k = 1600f / maxOf(bmp.width, bmp.height)
        val out = if (k < 1f) android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
        java.io.ByteArrayOutputStream().also { out.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, it) }.toByteArray()
    } catch (e: Exception) { null }

    private val editWords = Regex("(edit|badlo|badal|hatao|remove|background|filter|enhance|sharp|blur|brighten|bright|color|colour|retouch|crop|style|cartoon|anime|bana do|banao|add|lagao|saaf|clean|upscale|hd)", RegexOption.IGNORE_CASE)

    /** Edited photo ko Gallery (Pictures/Jarvis) mein save karta hai. */
    private fun saveToGallery(bytes: ByteArray): String {
        val name = "jarvis_${System.currentTimeMillis()}.jpg"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = android.content.ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Jarvis")
                }
                val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { it.write(bytes) }
                return "Gallery > Pictures/Jarvis"
            }
        } catch (_: Exception) { }
        val f = File(getExternalFilesDir(null) ?: filesDir, name)
        f.writeBytes(bytes)
        return f.absolutePath
    }

    private fun photoCommand(text: String, jpg: ByteArray) {
        addChat("Tu: $text")
        val wantsEdit = editWords.containsMatchIn(text)
        setStatus(if (wantsEdit) "Photo edit kar raha hoon…" else "Photo dekh raha hoon…")
        io.execute {
            if (wantsEdit) {
                val key = SecurePrefs.geminiKey(this)
                if (key == null) {
                    ui.post { addChat("JARVIS: Photo edit ke liye Gemini key chahiye (Settings ⚙).") }
                    return@execute
                }
                try {
                    val out = Gemini.editImage(this,
                        "Is photo ko professional quality mein edit karo. Chehra, pehchaan aur baaki cheezein waisi hi rakho jab tak kehna na ho. Instruction: $text", jpg)
                    val bmp = android.graphics.BitmapFactory.decodeByteArray(out, 0, out.size)
                    val jpgOut = java.io.ByteArrayOutputStream().also { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) }.toByteArray()
                    val where = saveToGallery(jpgOut)
                    pendingPhoto = jpgOut   // agla edit isi nayi photo par
                    ui.post {
                        addChat("JARVIS: Edit ho gaya, save kiya: $where. Aur badlav chahiye to bolo.")
                        say("Edit ho gaya")
                    }
                } catch (e: Exception) {
                    ui.post { addChat("JARVIS: Edit nahi hua: ${e.message}"); setStatus("") }
                }
            } else {
                val r = CommandRouter.vision(this, jpg, text)
                ui.post { addChat("JARVIS ${r.mood?.emoji ?: ""}: ${r.text}"); say(r.text) }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VID) {
            if (resultCode != RESULT_OK) return
            val uri = data?.data ?: return
            val send = Intent(Intent.ACTION_SEND).setType("video/*").putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            try { startActivity(Intent(send).setPackage("com.lemon.lvoverseas")) }
            catch (e: Exception) { startActivity(Intent.createChooser(send, "CapCut chuno")) }
            addChat("JARVIS: Video CapCut mein bhej di. Edit wahan hoga.")
            return
        }
        if (requestCode == REQ_PICK) {
            if (resultCode != RESULT_OK) return
            val uri = data?.data ?: return
            val b = loadScaled(uri)
            if (b == null) { setStatus("Photo padh nahi paaya"); return }
            pendingPhoto = b
            addChat("Tu: [photo chuni]")
            addChat("JARVIS: Photo mil gayi. Batao kya karna hai? (jaise: \"background hata do\", \"cartoon bana do\", ya \"ye kya hai?\"). Photo hatane ke liye: \"photo hatao\".")
            return
        }
        if (requestCode != REQ_CAM || resultCode != RESULT_OK) return
        val bytes = camFile().readBytes()
        val q = camQ
        addChat("Tu: [photo] $q")
        setStatus("Photo dekh raha hoon…")
        io.execute {
            val r = CommandRouter.vision(this, bytes, q)
            ui.post {
                addChat("JARVIS ${r.mood?.emoji ?: ""}: ${r.text}")
                say(r.text)
            }
        }
    }

    private fun handle(text: String) {
        if (Regex("^capcut (?:mein|me) (?:video )?(?:edit|kholo)", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            try { startActivityForResult(Intent.createChooser(i, "Video chuno"), REQ_VID) } catch (_: Exception) { }
            return
        }
        if (Regex("^photo (hatao|clear|reset)$", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            pendingPhoto = null; addChat("JARVIS: Photo hata di."); return
        }
        pendingPhoto?.let { if (!Regex("^(photo lo|camera)", RegexOption.IGNORE_CASE).containsMatchIn(text)) { photoCommand(text, it); return } }
        if (Regex("^(ye kya (hai|h)|dekh ke batao|photo lo|camera)", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            openCamera(text); return
        }
        addChat("Tu: $text")
        setStatus("Soch raha hoon…")
        io.execute {
            val reply = CommandRouter.process(this, text)
            ui.post {
                addChat("JARVIS ${reply.mood?.emoji ?: ""}: ${reply.text}")
                say(reply.text)
            }
        }
    }

    private fun toggleVoiceMode() {
        voiceMode = !voiceMode
        voiceErrors = 0
        updateVoiceBtn()
        if (voiceMode) {
            startListening()
        } else {
            sr?.destroy(); sr = null
            tts.stop()
            setStatus("")
            MonsterActivity.instance?.pushState("idle")
        }
    }

    private fun updateVoiceBtn() {
        voiceBtn.text = if (voiceMode) "■" else "🎤"
        voiceBtn.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (voiceMode) Color.parseColor(ACCENT_ON) else Color.parseColor(ACCENT))
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        sr?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        sr = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle?) {
                rec.destroy(); sr = null
                voiceErrors = 0
                val said = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (said.isNullOrBlank()) { afterSpeech(); return }
                handle(said)
            }
            override fun onError(error: Int) {
                rec.destroy(); sr = null
                if (!voiceMode) {
                    setStatus("")
                    addChat("Sun nahi paya, dobara bol.")
                    return
                }
                voiceErrors++
                if (voiceErrors >= 4) {               // lagatar awaaz nahi mili to voice mode band
                    voiceMode = false
                    updateVoiceBtn()
                    setStatus("Awaaz nahi mili, voice mode band.")
                    return
                }
                ui.postDelayed({ if (voiceMode) startListening() }, 700)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        setStatus(if (voiceMode) "Sun raha hoon… (voice mode ON)" else "Sun raha hoon…")
        MonsterActivity.instance?.pushState("listening")
        rec.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Lang.sttTag(this@MainActivity))
            if (Lang.pref(this@MainActivity) == "auto")
                putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("hi-IN", "en-IN"))
        })
    }

    private fun settingBtn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.parseColor("#263244"))
        textSize = 14f
        background = rounded(Color.parseColor("#F1F3F6"), dp(12).toFloat(), Color.parseColor("#B9C8DD"))
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
    }

    private fun openScreen(i: Intent) {
        try { startActivity(i) } catch (_: Exception) { Toast.makeText(this, "Ye screen is phone par nahi khuli.", Toast.LENGTH_SHORT).show() }
    }

    private fun showLangPicker(onPicked: () -> Unit) {
        val codes = Lang.choices.map { it.first }
        val labels = Lang.choices.map { it.second }.toTypedArray()
        val cur = codes.indexOf(Lang.pref(this)).coerceAtLeast(0)
        AlertDialog.Builder(this, DARK_DIALOG).setTitle("Bhasha chuno")
            .setSingleChoiceItems(labels, cur) { d, which ->
                Lang.setPref(this, codes[which])
                onPicked()
                d.dismiss()
            }
            .setNegativeButton("Band", null)
            .show()
    }

    private fun requestDefaultDialerRole() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = getSystemService(android.app.role.RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(android.app.role.RoleManager.ROLE_DIALER)) {
                    if (roleManager.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER)) {
                        Toast.makeText(this, "JARVIS already default Phone app hai.", Toast.LENGTH_LONG).show()
                    } else {
                        startActivityForResult(roleManager.createRequestRoleIntent(android.app.role.RoleManager.ROLE_DIALER), 41)
                    }
                } else {
                    Toast.makeText(this, "Is phone par Dialer role available nahi hai.", Toast.LENGTH_LONG).show()
                }
            } else {
                val i = Intent(android.telecom.TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                    .putExtra(android.telecom.TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                startActivityForResult(i, 41)
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Default Phone app setting nahi khul saki.", Toast.LENGTH_LONG).show()
        }
    }


    private fun addSettingToggle(
        box: LinearLayout,
        label: String,
        checked: Boolean,
        onChanged: (Boolean) -> Unit
    ): Switch {
        val sw = Switch(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.parseColor("#263244"))
            isChecked = checked
            setPadding(dp(10), dp(8), dp(10), dp(8))
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#2878E8"))
            setOnCheckedChangeListener { _, value -> playUiSound(); onChanged(value) }
            background = rounded(Color.parseColor("#F1F3F6"), dp(12).toFloat(), Color.parseColor("#D5DAE2"))
        }
        box.addView(sw, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        return sw
    }

    private fun phoneControlReady(): Boolean =
        JarvisAccessibilityService.instance != null && notifAccessOn() && Settings.System.canWrite(this)

    private fun playUiSound() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 28)
            tone.startTone(ToneGenerator.TONE_PROP_ACK, 110)
            ui.postDelayed({ tone.release() }, 250)
        } catch (_: Exception) { }
    }

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setBackgroundColor(Color.parseColor("#E9ECF1"))
        }
        val nameField = EditText(this).apply {
            hint = "Aapka naam"
            setText(prefs.getString("name", "Ayush"))
            setTextColor(Color.parseColor("#263244"))
            setHintTextColor(Color.parseColor("#687386"))
        }
        val savedKeys = SecurePrefs.geminiKeys(this)
        val keyFields = (1..6).map { slot -> EditText(this).apply {
            hint = "Gemini API key $slot"
            setText(savedKeys.getOrNull(slot - 1).orEmpty())
            setSingleLine(true)
            setTextColor(Color.parseColor(if (SecurePrefs.isQuotaLimited(this@MainActivity, slot) || SecurePrefs.isInvalid(this@MainActivity, slot)) "#9299A5" else "#263244"))
            setHintTextColor(Color.parseColor("#687386"))
        } }
        fun section(label: String) {
            box.addView(TextView(this).apply {
                text = label
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.parseColor("#526176"))
                setPadding(dp(2), dp(12), 0, dp(2))
            })
        }
        section("PROFILE")
        box.addView(TextView(this).apply { text = "Naam"; setTextColor(Color.parseColor("#263244")) })
        box.addView(nameField)
        box.addView(TextView(this).apply {
            text = "Gemini API keys (limit khatam hone par auto-switch)"
            setTextColor(Color.parseColor("#263244"))
        })
        keyFields.forEachIndexed { index, field ->
            box.addView(TextView(this).apply {
                text = when {
                    SecurePrefs.isQuotaLimited(this@MainActivity, index + 1) -> "Key ${index + 1} • QUOTA FULL"
                    SecurePrefs.isInvalid(this@MainActivity, index + 1) -> "Key ${index + 1} • INVALID / CHECK KEY"
                    else -> "Key ${index + 1} • READY"
                }
                setTextColor(Color.parseColor(if (SecurePrefs.isQuotaLimited(this@MainActivity, index + 1) || SecurePrefs.isInvalid(this@MainActivity, index + 1)) "#9299A5" else "#526176"))
                textSize = 12f
            })
            box.addView(field)
        }
        box.addView(settingBtn("API key status reset karo") { SecurePrefs.resetQuotaFlags(this); Toast.makeText(this, "Key status reset ho gaya. Invalid ya quota-full key dobara try hogi.", Toast.LENGTH_LONG).show(); showSettings() })

        section("PHONE CONTROL")
        addSettingToggle(box, "Phone control — required permissions", phoneControlReady()) { enabled ->
            if (enabled) {
                prefs.edit().putBoolean("phone_control_master", true).apply()
                if (!phoneControlReady()) runSetup()
            } else {
                prefs.edit().putBoolean("phone_control_master", false).apply()
                AlertDialog.Builder(this, DARK_DIALOG)
                    .setTitle("Phone control band karna")
                    .setMessage("Android Settings > Accessibility mein JARVIS service ko OFF karein. Notification access aur special permissions bhi wahin se band ki ja sakti hain.")
                    .setPositiveButton("Accessibility kholo") { _, _ -> openScreen(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    .setNegativeButton("Baad mein", null).show()
            }
        }
        addSettingToggle(box, "Brightness permission", Settings.System.canWrite(this)) { enabled ->
            if (enabled != Settings.System.canWrite(this)) {
                openScreen(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).setData(Uri.parse("package:$packageName")))
            }
        }
        addSettingToggle(box, "Notification access", notifAccessOn()) { enabled ->
            if (enabled != notifAccessOn()) openScreen(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        val dialerActive = try { getSystemService(android.telecom.TelecomManager::class.java)?.defaultDialerPackage == packageName } catch (_: Exception) { false }
        addSettingToggle(box, "Incoming call assistant (default Phone app)", dialerActive) { enabled ->
            if (enabled) requestDefaultDialerRole()
            else Toast.makeText(this, "Default Phone app ko Android ke Default apps settings se badlein.", Toast.LENGTH_LONG).show()
        }
        addSettingToggle(box, "Wake word: Jarvis", prefs.getBoolean("wake_word", false)) { enabled ->
            prefs.edit().putBoolean("wake_word", enabled).apply()
            val i = Intent(this, WakeService::class.java)
            try {
                if (enabled) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    } else {
                        prefs.edit().putBoolean("wake_word", false).apply()
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                    }
                } else stopService(i)
            } catch (_: Exception) {
                prefs.edit().putBoolean("wake_word", false).apply()
                Toast.makeText(this, "Wake word start nahi ho saka.", Toast.LENGTH_SHORT).show()
            }
        }
        addSettingToggle(box, "Message padh ke batao", prefs.getBoolean("smart_read", false)) { enabled ->
            prefs.edit().putBoolean("smart_read", enabled).apply()
        }

        section("ANIMATION & CONNECTIVITY")
        addSettingToggle(box, "USB connect hone par Cast notification", prefs.getBoolean("usb_cast", false)) { enabled ->
            prefs.edit().putBoolean("usb_cast", enabled).apply()
            try { if (enabled) UsbWatchService.start(this) else UsbWatchService.stop(this) } catch (_: Exception) { }
        }
        box.addView(settingBtn("🌐 Bhasha: " + Lang.labelOf(Lang.pref(this))) {
            showLangPicker { /* dialog closes; reopen to refresh label */ }
        })
        box.addView(settingBtn("Screen cast abhi karo (TV / Chromecast)") { openScreen(Intent(Settings.ACTION_CAST_SETTINGS)) })
        box.addView(settingBtn("Bluetooth Remote kholo") { startActivity(Intent(this, BtRemoteActivity::class.java)) })
        box.addView(settingBtn("Bluetooth device settings kholo") { openScreen(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })

        AlertDialog.Builder(this, DARK_DIALOG)
            .setTitle("J A R V I S  •  SETTINGS")
            .setView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#E9ECF1")); addView(box) })
            .setPositiveButton("Save") { _, _ ->
                val name = nameField.text.toString().trim().ifEmpty { "Ayush" }
                prefs.edit().putString("name", name).apply()
                greetText.text = greetingText()
                SecurePrefs.setGeminiKeys(this@MainActivity, keyFields.map { it.text.toString().trim() })
            }
            .setNegativeButton("Close", null)
            .show()
    }

    override fun onDestroy() {
        sr?.destroy()
        tts.shutdown()
        io.shutdown()
        MonsterActivity.instance?.finish()
        super.onDestroy()
    }
}

/** JARVIS ka logo: dheere ghoomta vortex (SCREEN blend, taaki kaala kinara background mein ghul jaaye). */
private class JarvisLogoView(ctx: Context) : View(ctx) {
    private val bmp = android.graphics.BitmapFactory.decodeResource(ctx.resources, R.drawable.logo_vortex)
    private val img = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
    }
    private val t0 = System.currentTimeMillis()

    override fun onDraw(c: Canvas) {
        val t = (System.currentTimeMillis() - t0) / 1000f
        val s = minOf(width, height).toFloat()
        c.save()
        c.translate(width / 2f, height / 2f)
        c.rotate(t * 20f)
        c.scale(s / bmp.width, s / bmp.height)
        c.drawBitmap(bmp, -bmp.width / 2f, -bmp.height / 2f, img)
        c.restore()
        postInvalidateOnAnimation()
    }
}
