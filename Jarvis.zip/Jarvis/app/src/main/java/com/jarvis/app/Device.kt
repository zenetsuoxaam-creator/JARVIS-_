package com.jarvis.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.Cursor
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.content.ClipboardManager
import org.json.JSONObject
import java.net.URLEncoder

/** Phone ke kaam. Ye sab background thread se chalte hain. */
object Device {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun granted(ctx: Context, p: String) =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (lvl < 0) "Battery ka pata nahi chal raha." else "Battery ${lvl * 100 / sc}% hai."
    }

    fun torch(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(CameraManager::class.java)
        cm.setTorchMode(cm.cameraIdList[0], on)
        "Torch ${if (on) "on" else "off"} kar di."
    } catch (e: Exception) { "Torch nahi chal payi." }

    fun brightness(ctx: Context, pct: Int): String {
        if (!Settings.System.canWrite(ctx)) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS)
                .setData(Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Pehle 'Modify system settings' ON karo, phir bolna."
        }
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, 0)
        Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
            (pct.coerceIn(0, 100) * 255 / 100))
        return "Brightness $pct% kar di."
    }

    /** Contacts mein naam dhoondhta hai. Pair(naam, number) */
    fun findContact(ctx: Context, name: String): Pair<String, String>? {
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        val c: Cursor = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"), null
        ) ?: return null
        c.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        return null
    }

    fun call(ctx: Context, name: String): String {
        val (cn, num) = findContact(ctx, name) ?: return "$name contacts mein nahi mila (ya contacts permission nahi hai)."
        return try {
            ctx.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "$cn ko call laga raha hoon."
        } catch (e: Exception) { "Call nahi lag payi: permission check karo." }
    }

    fun sms(ctx: Context, name: String, msg: String): String {
        val (cn, num) = findContact(ctx, name) ?: return "$name contacts mein nahi mila."
        return try {
            val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                     else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendTextMessage(num, null, msg, null, null)
            "$cn ko SMS bhej diya."
        } catch (e: Exception) { "SMS nahi gaya: ${e.message}" }
    }

    /** WhatsApp message draft kholta hai. Send button user ko dabana hoga (Android isse block karta hai). */
    fun whatsapp(ctx: Context, name: String, msg: String): String {
        val (cn, num) = findContact(ctx, name) ?: return "$name contacts mein nahi mila."
        var clean = num.filter { it.isDigit() }
        if (clean.length == 10) clean = "91$clean"
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean?text=${enc(msg)}"))
                .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "$cn ke liye WhatsApp message khol diya. Send tum dabana."
        } catch (e: Exception) { "WhatsApp nahi khul paya." }
    }

    fun readSms(ctx: Context): String {
        if (!granted(ctx, Manifest.permission.READ_SMS)) return "SMS padhne ki permission do."
        val c = ctx.contentResolver.query(Uri.parse("content://sms/inbox"),
            arrayOf("address", "body"), null, null, "date DESC") ?: return "SMS nahi mile."
        val out = StringBuilder()
        c.use { var n = 0; while (it.moveToNext() && n < 3) { out.append("${it.getString(0)}: ${it.getString(1)}\n"); n++ } }
        return if (out.isEmpty()) "Inbox khali hai." else out.toString().trim()
    }

    fun clipboard(ctx: Context): String {
        val cb = ctx.getSystemService(ClipboardManager::class.java)
        val t = cb.primaryClip?.getItemAt(0)?.text
        return if (t.isNullOrBlank()) "Clipboard khali hai." else "Clipboard mein hai: $t"
    }

    fun alarm(ctx: Context, hour: Int, min: Int): String {
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm").putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Alarm laga diya: %02d:%02d.".format(hour, min)
    }

    /** Open-Meteo: bina key ke free mausam. Network call, background thread par. */
    fun weather(city: String): String = try {
        val geo = JSONObject(java.net.URL("https://geocoding-api.open-meteo.com/v1/search?name=${enc(city)}&count=1").readText())
        val r = geo.getJSONArray("results").getJSONObject(0)
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}&current_weather=true"
        val cur = JSONObject(java.net.URL(url).readText()).getJSONObject("current_weather")
        "${r.getString("name")} mein abhi ${cur.getDouble("temperature")}°C hai."
    } catch (e: Exception) { "Mausam nahi mila. Shehar ka naam sahi likho." }
}

/** Yaad rakhne wali cheezein (facts + notes), phone mein hi save hoti hain. */
object Memory {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun facts(ctx: Context): List<String> = prefs(ctx).getStringSet("facts", emptySet())!!.toList()

    fun addFact(ctx: Context, f: String) {
        val s = facts(ctx).toMutableSet(); s.add(f)
        prefs(ctx).edit().putStringSet("facts", s).apply()
    }

    fun clearFacts(ctx: Context) = prefs(ctx).edit().remove("facts").apply()

    fun notes(ctx: Context): List<String> =
        prefs(ctx).getString("notes", "")!!.split("\n").filter { it.isNotBlank() }

    fun addNote(ctx: Context, n: String) {
        prefs(ctx).edit().putString("notes", (notes(ctx) + n).joinToString("\n")).apply()
    }
}
