package com.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.annotation.RequiresApi
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Phone ko Bluetooth keyboard + mouse + media remote bana deta hai.
 * Computer, laptop, TV, doosra phone (jo Bluetooth keyboard/mouse support karta ho) ko control kar sakte ho.
 * Speaker / headphone jaise device ke liye sirf system Bluetooth settings se connect hota hai (audio ke liye).
 */
@RequiresApi(28)
object BtHid {
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var adapter: BluetoothAdapter? = null
    @Volatile var registered = false
    private var starting = false
    var onChange: (() -> Unit)? = null

    private val descriptor: ByteArray = intArrayOf(
        // Keyboard (report 1)
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
        0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
        0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
        0xC0,
        // Mouse (report 2)
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85, 0x02, 0x09, 0x01, 0xA1, 0x00,
        0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,
        0xC0, 0xC0,
        // Media keys (report 3): vol+, vol-, mute, play/pause, next, prev, home, back
        0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x03, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08,
        0x09, 0xE9, 0x09, 0xEA, 0x09, 0xE2, 0x09, 0xCD, 0x09, 0xB5, 0x09, 0xB6, 0x0A, 0x23, 0x02, 0x0A, 0x24, 0x02,
        0x81, 0x02, 0xC0
    ).map { it.toByte() }.toByteArray()

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            BtHid.registered = registered
            onChange?.invoke()
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) host = device
            else if (state == BluetoothProfile.STATE_DISCONNECTED && host?.address == device.address) host = null
            onChange?.invoke()
        }
    }

    @SuppressLint("MissingPermission")
    fun start(ctx: Context) {
        if (hid != null || starting) return
        val ad = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
        adapter = ad
        starting = true
        try {
            ad.getProfileProxy(ctx.applicationContext, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                    if (profile != BluetoothProfile.HID_DEVICE) return
                    val h = proxy as BluetoothHidDevice
                    hid = h
                    val sdp = BluetoothHidDeviceAppSdpSettings(
                        "JARVIS Remote", "Phone as keyboard, mouse and media remote", "JARVIS",
                        BluetoothHidDevice.SUBCLASS1_COMBO, descriptor)
                    h.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), cb)
                }

                override fun onServiceDisconnected(profile: Int) {
                    hid = null; host = null; registered = false; starting = false
                    onChange?.invoke()
                }
            }, BluetoothProfile.HID_DEVICE)
        } catch (_: SecurityException) { starting = false }
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        try {
            hid?.unregisterApp()
            hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
        } catch (_: Exception) { }
        hid = null; host = null; registered = false; starting = false
    }

    @SuppressLint("MissingPermission")
    fun connect(d: BluetoothDevice): Boolean = try { hid?.connect(d) ?: false } catch (_: Exception) { false }

    @SuppressLint("MissingPermission")
    fun disconnect() { try { host?.let { hid?.disconnect(it) } } catch (_: Exception) { } }

    @SuppressLint("MissingPermission")
    fun hostName(): String? = try { host?.name ?: host?.address } catch (_: Exception) { null }

    val connected: Boolean get() = host != null

    @SuppressLint("MissingPermission")
    fun hostAddress(): String? = try { host?.address } catch (_: Exception) { null }

    /** BluetoothClass.Device.Major.* (COMPUTER / PHONE / AUDIO_VIDEO ...), pata na ho to -1. */
    @SuppressLint("MissingPermission")
    fun hostMajorClass(): Int = try { host?.bluetoothClass?.majorDeviceClass ?: -1 } catch (_: Exception) { -1 }

    /** Paired (bonded) device ko naam se dhoondh kar HID connect karta hai. */
    @SuppressLint("MissingPermission")
    fun connectByName(name: String): String? {
        val d = try {
            adapter?.bondedDevices?.firstOrNull { (it.name ?: "").contains(name, ignoreCase = true) }
        } catch (_: Exception) { null } ?: return null
        connect(d)
        return try { d.name ?: d.address } catch (_: Exception) { name }
    }

    @SuppressLint("MissingPermission")
    private fun send(id: Int, data: ByteArray) {
        val h = hid ?: return
        val d = host ?: return
        try { h.sendReport(d, id, data) } catch (_: Exception) { }
    }

    fun key(code: Int, mod: Int = 0) {
        val down = ByteArray(8)
        down[0] = mod.toByte(); down[2] = code.toByte()
        send(1, down); send(1, ByteArray(8))
    }

    fun typeText(s: String) {
        for (c in s) {
            val k = ascii(c) ?: continue
            key(k.first, k.second)
            Thread.sleep(12)
        }
    }

    fun media(bit: Int) {
        send(3, byteArrayOf((1 shl bit).toByte())); send(3, byteArrayOf(0))
    }

    fun move(dx: Int, dy: Int) {
        send(2, byteArrayOf(0, dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(), 0))
    }

    fun wheel(n: Int) { send(2, byteArrayOf(0, 0, 0, n.coerceIn(-127, 127).toByte())) }

    /** buttons: 1 = left, 2 = right */
    fun click(buttons: Int) {
        send(2, byteArrayOf(buttons.toByte(), 0, 0, 0)); send(2, byteArrayOf(0, 0, 0, 0))
    }

    /** (HID keycode, modifier) — modifier 2 = Shift. Sirf English/ASCII keys. */
    private fun ascii(c: Char): Pair<Int, Int>? = when (c) {
        in 'a'..'z' -> (0x04 + (c - 'a')) to 0
        in 'A'..'Z' -> (0x04 + (c - 'A')) to 2
        in '1'..'9' -> (0x1E + (c - '1')) to 0
        '0' -> 0x27 to 0
        ' ' -> 0x2C to 0
        '\n' -> 0x28 to 0
        '\t' -> 0x2B to 0
        '-' -> 0x2D to 0
        '_' -> 0x2D to 2
        '=' -> 0x2E to 0
        '+' -> 0x2E to 2
        '[' -> 0x2F to 0
        '{' -> 0x2F to 2
        ']' -> 0x30 to 0
        '}' -> 0x30 to 2
        '\\' -> 0x31 to 0
        '|' -> 0x31 to 2
        ';' -> 0x33 to 0
        ':' -> 0x33 to 2
        '\'' -> 0x34 to 0
        '"' -> 0x34 to 2
        '`' -> 0x35 to 0
        '~' -> 0x35 to 2
        ',' -> 0x36 to 0
        '<' -> 0x36 to 2
        '.' -> 0x37 to 0
        '>' -> 0x37 to 2
        '/' -> 0x38 to 0
        '?' -> 0x38 to 2
        '!' -> 0x1E to 2
        '@' -> 0x1F to 2
        '#' -> 0x20 to 2
        '$' -> 0x21 to 2
        '%' -> 0x22 to 2
        '^' -> 0x23 to 2
        '&' -> 0x24 to 2
        '*' -> 0x25 to 2
        '(' -> 0x26 to 2
        ')' -> 0x27 to 2
        else -> null
    }
}

@SuppressLint("NewApi", "MissingPermission")
class BtRemoteActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var deviceBox: LinearLayout
    private lateinit var controls: LinearLayout
    private val REQ = 31

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(fill); cornerRadius = dp(r).toFloat(); setStroke(dp(1), Color.parseColor("#2A2A33")) }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = box(Color.parseColor("#1E1E26"), 12)
        setOnClickListener { onClick() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0B0F")
        window.navigationBarColor = Color.parseColor("#0B0B0F")
        buildUi()
        if (Build.VERSION.SDK_INT < 28) {
            status.text = "Is phone ka Android purana hai. Bluetooth remote ke liye Android 9 ya naya chahiye."
            return
        }
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            for (p in listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE))
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ) else initBt()
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= 28 && btPermsOk()) initBt()
    }

    private fun btPermsOk(): Boolean =
        Build.VERSION.SDK_INT < 31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED)

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) initBt()
            else status.text = "Bluetooth permission nahi mili. App settings mein 'Nearby devices' allow karo."
        }
    }

    private fun adapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private fun initBt() {
        val ad = adapter()
        if (ad == null) { status.text = "Is phone mein Bluetooth nahi hai."; return }
        if (!ad.isEnabled) {
            status.text = "Bluetooth band hai. Neeche 'Bluetooth ON karo' dabao."
            return
        }
        BtHid.onChange = { ui.post { refresh() } }
        BtHid.start(this)
        refresh()
    }

    private fun refresh() {
        val ad = adapter()
        if (ad == null || !ad.isEnabled) { status.text = "Bluetooth band hai."; setControls(false); return }
        val name = BtHid.hostName()
        status.text = when {
            name != null && BtHid.connected -> "Connected: $name ✅"
            BtHid.registered -> "Taiyaar. Neeche se device chuno (pehle us device se pair karna zaroori hai)."
            else -> "Bluetooth remote setup ho raha hai…"
        }
        setControls(BtHid.connected)
        deviceBox.removeAllViews()
        try {
            val list = ad.bondedDevices.toList().sortedBy { it.name ?: "" }
            if (list.isEmpty()) deviceBox.addView(TextView(this).apply {
                text = "Koi paired device nahi. Pehle 'Naya device pair karo' dabao."
                setTextColor(Color.parseColor("#8B8B98"))
            })
            for (d in list) {
                deviceBox.addView(btn((d.name ?: d.address) + if (BtHid.hostName() == (d.name ?: d.address) && BtHid.connected) "  ✅" else "") {
                    status.text = "${d.name ?: d.address} se connect ho raha hai…"
                    if (!BtHid.connect(d)) status.text = "Connect nahi hua. Doosre device par 'JARVIS Remote' ko allow/accept karo."
                })
            }
        } catch (_: SecurityException) { }
    }

    private fun setControls(on: Boolean) {
        controls.alpha = if (on) 1f else 0.35f
        setEnabledDeep(controls, on)
    }

    private fun setEnabledDeep(v: View, on: Boolean) {
        v.isEnabled = on
        if (v is LinearLayout) for (i in 0 until v.childCount) setEnabledDeep(v.getChildAt(i), on)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "Bluetooth Remote"; textSize = 22f; setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "Phone ko keyboard, mouse aur media remote banao. Computer, laptop, TV ya doosre phone ko control karo. " +
                "Speaker/headphone ko system Bluetooth settings se connect karo."
            textSize = 12f; setTextColor(Color.parseColor("#8B8B98")); setPadding(0, dp(4), 0, dp(8))
        })
        status = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#FF6A6A")); setPadding(0, dp(4), 0, dp(8)) }
        root.addView(status)

        root.addView(btn("Bluetooth ON karo") {
            try { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) { }
        })
        root.addView(row(
            btn("Naya device pair karo") {
                try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (_: Exception) { }
            },
            btn("Phone ko dikhao (2 min)") {
                try {
                    startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                        .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
                } catch (_: Exception) { }
            }
        ))
        root.addView(TextView(this).apply { text = "Paired devices (tap = connect):"; setTextColor(Color.WHITE); setPadding(0, dp(8), 0, dp(4)) })
        deviceBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(deviceBox)
        root.addView(btn("List refresh karo") { if (Build.VERSION.SDK_INT >= 28) refresh() })
        root.addView(btn("Disconnect") { if (Build.VERSION.SDK_INT >= 28) BtHid.disconnect() })

        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(12), 0, 0) }
        controls.addView(TextView(this).apply {
            text = "Touchpad: ungli ghumao = mouse, tap = click, do ungli upar-neeche = scroll"
            textSize = 12f; setTextColor(Color.parseColor("#8B8B98"))
        })
        controls.addView(Pad(this), LinearLayout.LayoutParams(-1, dp(200)).apply { topMargin = dp(6) })
        controls.addView(row(btn("Left click") { BtHid.click(1) }, btn("Right click") { BtHid.click(2) }))
        controls.addView(row(btn("Vol −") { BtHid.media(1) }, btn("Mute") { BtHid.media(2) }, btn("Vol +") { BtHid.media(0) }))
        controls.addView(row(btn("⏮") { BtHid.media(5) }, btn("⏯") { BtHid.media(3) }, btn("⏭") { BtHid.media(4) }))
        controls.addView(row(btn("Home") { BtHid.media(6) }, btn("Back") { BtHid.media(7) }, btn("Esc") { BtHid.key(0x29) }))
        controls.addView(row(View(this), btn("▲") { BtHid.key(0x52) }, View(this)))
        controls.addView(row(btn("◀") { BtHid.key(0x50) }, btn("OK") { BtHid.key(0x28) }, btn("▶") { BtHid.key(0x4F) }))
        controls.addView(row(View(this), btn("▼") { BtHid.key(0x51) }, View(this)))

        val typed = EditText(this).apply {
            hint = "Yahan likho (English), phir 'Bhejo'"
            setHintTextColor(Color.parseColor("#8B8B98")); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT
        }
        controls.addView(typed)
        controls.addView(row(
            btn("Bhejo") {
                val t = typed.text.toString()
                typed.setText("")
                io.execute { BtHid.typeText(t) }
            },
            btn("Enter") { BtHid.key(0x28) },
            btn("⌫") { BtHid.key(0x2A) }
        ))
        root.addView(controls)
        setControls(false)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0B0F"))
            addView(root)
        })
    }

    /** Touchpad: ek ungli = mouse, tap = click, do ungli = scroll. */
    private inner class Pad(ctx: Context) : View(ctx) {
        private var lx = 0f
        private var ly = 0f
        private var lastY2 = 0f
        private var downAt = 0L
        private var moved = 0f

        init { background = box(Color.parseColor("#16161C"), 16) }

        private fun avgY(e: MotionEvent): Float {
            var s = 0f
            for (i in 0 until e.pointerCount) s += e.getY(i)
            return s / e.pointerCount
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (!isEnabled) return true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; downAt = e.eventTime; moved = 0f }
                MotionEvent.ACTION_POINTER_DOWN -> lastY2 = avgY(e)
                MotionEvent.ACTION_POINTER_UP -> {
                    val keep = if (e.actionIndex == 0) 1 else 0
                    lx = e.getX(keep); ly = e.getY(keep)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {
                        val y = avgY(e)
                        val dy = y - lastY2
                        lastY2 = y
                        val n = (-dy / 10f).roundToInt()
                        if (n != 0) BtHid.wheel(n)
                    } else {
                        val dx = e.x - lx
                        val dy = e.y - ly
                        lx = e.x; ly = e.y
                        moved += abs(dx) + abs(dy)
                        BtHid.move((dx * 1.8f).roundToInt(), (dy * 1.8f).roundToInt())
                    }
                }
                MotionEvent.ACTION_UP -> if (e.eventTime - downAt < 220 && moved < 18f) BtHid.click(1)
            }
            return true
        }
    }

    override fun onDestroy() {
        if (Build.VERSION.SDK_INT >= 28) { BtHid.onChange = null; BtHid.stop() }
        io.shutdown()
        super.onDestroy()
    }
}
