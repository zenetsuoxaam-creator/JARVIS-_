package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API key encrypted store mein rakhi jaati hai (Android Keystore se encrypted).
 * Pehle ki plain-text key ko ek baar migrate karke purani jagah se hata deta hai.
 */
object SecurePrefs {
    private const val FILE = "jarvis_secure"
    private const val KEY_GEMINI = "gemini_key"
    private const val KEY_PREFIX = "gemini_key_"
    private const val QUOTA_PREFIX = "gemini_quota_"
    private const val QUOTA_TIME_PREFIX = "gemini_quota_time_"
    private const val INVALID_PREFIX = "gemini_invalid_"
    private const val ACTIVE_KEY = "gemini_active_key"

    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(ctx: Context): SharedPreferences {
        cached?.let { return it }
        val app = ctx.applicationContext
        val master = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val p = EncryptedSharedPreferences.create(
            app, FILE, master,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        cached = p
        return p
    }

    private fun migrate(ctx: Context) {
        val old = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
        val k = old.getString(KEY_GEMINI, null) ?: return
        if (k.isNotEmpty()) prefs(ctx).edit().putString(KEY_GEMINI, k).apply()
        old.edit().remove(KEY_GEMINI).apply()
    }

    fun geminiKeys(ctx: Context): List<String> {
        migrate(ctx)
        val p = prefs(ctx)
        return (1..6).map { i -> p.getString(KEY_PREFIX + i, if (i == 1) p.getString(KEY_GEMINI, "") else "") ?: "" }
    }

    /**
     * Returns the next configured, non-duplicate key that is not quota-limited.
     * Excluded keys are keys already attempted during the current request, so a
     * duplicate pasted into two slots is never sent twice.
     */
    fun geminiKey(ctx: Context, excluded: Set<String> = emptySet()): String? {
        val p = prefs(ctx)
        val keys = geminiKeys(ctx)
        val start = p.getInt(ACTIVE_KEY, 0).coerceIn(0, 5)
        for (offset in 0 until 6) {
            val i = (start + offset) % 6
            val key = keys[i].trim()
            if (key.isNotEmpty() && key !in excluded && !isQuotaLimited(ctx, i + 1) && !isInvalid(ctx, i + 1)) {
                p.edit().putInt(ACTIVE_KEY, i).apply()
                return key
            }
        }
        return null
    }

    fun keyIndex(ctx: Context, key: String): Int = geminiKeys(ctx).indexOf(key).takeIf { it >= 0 } ?: 0

    fun markInvalid(ctx: Context, key: String) {
        val p = prefs(ctx); val i = keyIndex(ctx, key) + 1
        p.edit().putBoolean(INVALID_PREFIX + i, true).putInt(ACTIVE_KEY, i % 6).apply()
    }

    fun isInvalid(ctx: Context, slot: Int): Boolean = prefs(ctx).getBoolean(INVALID_PREFIX + slot, false)

    fun markQuota(ctx: Context, key: String) {
        val p = prefs(ctx); val i = keyIndex(ctx, key) + 1
        p.edit().putBoolean(QUOTA_PREFIX + i, true).putLong(QUOTA_TIME_PREFIX + i, System.currentTimeMillis()).putInt(ACTIVE_KEY, i % 6).apply()
    }

    fun isQuotaLimited(ctx: Context, slot: Int): Boolean {
        val p = prefs(ctx)
        if (!p.getBoolean(QUOTA_PREFIX + slot, false)) return false
        val markedAt = p.getLong(QUOTA_TIME_PREFIX + slot, 0L)
        // Automatically retry a quota-limited key after 24 hours; provider limits may reset on another schedule.
        if (markedAt > 0L && System.currentTimeMillis() - markedAt >= 24L * 60L * 60L * 1000L) {
            p.edit().putBoolean(QUOTA_PREFIX + slot, false).apply()
            return false
        }
        return true
    }

    fun setGeminiKeys(ctx: Context, keys: List<String>) {
        val p = prefs(ctx).edit()
        for (i in 1..6) {
            val value = keys.getOrNull(i - 1)?.trim().orEmpty()
            p.putString(KEY_PREFIX + i, value).putBoolean(QUOTA_PREFIX + i, false).putBoolean(INVALID_PREFIX + i, false)
        }
        p.putString(KEY_GEMINI, keys.firstOrNull()?.trim().orEmpty()).putInt(ACTIVE_KEY, 0).apply()
    }

    fun setGeminiKey(ctx: Context, key: String) = setGeminiKeys(ctx, listOf(key))

    fun resetQuotaFlags(ctx: Context) {
        val e = prefs(ctx).edit(); for (i in 1..6) e.putBoolean(QUOTA_PREFIX + i, false).putBoolean(INVALID_PREFIX + i, false)
        e.putInt(ACTIVE_KEY, 0).apply()
    }
}
