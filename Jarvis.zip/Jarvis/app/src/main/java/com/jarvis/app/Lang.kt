package com.jarvis.app

import android.content.Context
import java.util.Locale

/** Bhasha (language) ka sab kaam: user ki pasand, TTS/STT ke tags, bolne se pehle text saaf karna. */
object Lang {
    /** code to dikhne wala naam. "auto" = jis bhasha mein user bole, usi mein jawab. */
    val choices: List<Pair<String, String>> = listOf(
        "auto" to "Auto (jis bhasha mein bolu, usi mein jawab)",
        "hi" to "हिन्दी (Hindi)", "en" to "English", "bn" to "বাংলা (Bengali)", "ta" to "தமிழ் (Tamil)",
        "te" to "తెలుగు (Telugu)", "mr" to "मराठी (Marathi)", "gu" to "ગુજરાતી (Gujarati)",
        "kn" to "ಕನ್ನಡ (Kannada)", "ml" to "മലയാളം (Malayalam)", "pa" to "ਪੰਜਾਬੀ (Punjabi)",
        "ur" to "اردو (Urdu)", "es" to "Español", "fr" to "Français", "de" to "Deutsch",
        "ar" to "العربية (Arabic)", "ru" to "Русский", "ja" to "日本語", "ko" to "한국어", "zh" to "中文"
    )

    private val promptNames = mapOf(
        "hi" to "Hindi (Devanagari script)", "en" to "English", "bn" to "Bengali", "ta" to "Tamil",
        "te" to "Telugu", "mr" to "Marathi", "gu" to "Gujarati", "kn" to "Kannada", "ml" to "Malayalam",
        "pa" to "Punjabi", "ur" to "Urdu", "es" to "Spanish", "fr" to "French", "de" to "German",
        "ar" to "Arabic", "ru" to "Russian", "ja" to "Japanese", "ko" to "Korean", "zh" to "Chinese"
    )

    private val spoken = mapOf(
        "hindi" to "hi", "हिंदी" to "hi", "हिन्दी" to "hi", "english" to "en", "angrezi" to "en", "अंग्रेजी" to "en",
        "bengali" to "bn", "bangla" to "bn", "tamil" to "ta", "telugu" to "te", "marathi" to "mr",
        "gujarati" to "gu", "kannada" to "kn", "malayalam" to "ml", "punjabi" to "pa", "urdu" to "ur",
        "spanish" to "es", "french" to "fr", "german" to "de", "arabic" to "ar", "russian" to "ru",
        "japanese" to "ja", "korean" to "ko", "chinese" to "zh", "auto" to "auto"
    )

    fun pref(ctx: Context): String =
        ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getString("lang", "auto") ?: "auto"

    fun setPref(ctx: Context, code: String) {
        ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putString("lang", code).apply()
        if (code != "auto") Persona.lang = code
    }

    fun codeFromName(name: String): String? = spoken[name.trim().lowercase()]

    fun labelOf(code: String): String = choices.firstOrNull { it.first == code }?.second ?: code

    /** Gemini ko batane ke liye: user ne bhasha fix ki hai to uska naam, warna null. */
    fun forcedName(ctx: Context): String? {
        val p = pref(ctx)
        return if (p == "auto") null else promptNames[p]
    }

    /** Abhi kis bhasha mein bolna/sunna hai. */
    fun speakLang(ctx: Context): String {
        val p = pref(ctx)
        return if (p == "auto") Persona.lang else p
    }

    fun locale(code: String): Locale = when (code.lowercase().substringBefore('-')) {
        "hi" -> Locale("hi", "IN")
        "en" -> Locale("en", "IN")
        "bn" -> Locale("bn", "IN")
        "ta" -> Locale("ta", "IN")
        "te" -> Locale("te", "IN")
        "mr" -> Locale("mr", "IN")
        "gu" -> Locale("gu", "IN")
        "kn" -> Locale("kn", "IN")
        "ml" -> Locale("ml", "IN")
        "pa" -> Locale("pa", "IN")
        "ur" -> Locale("ur", "IN")
        else -> Locale.forLanguageTag(code)
    }

    /** Speech-to-text ke liye tag (jaise hi-IN). */
    fun sttTag(ctx: Context): String {
        val c = speakLang(ctx).lowercase()
        return when (c.substringBefore('-')) {
            "hi" -> "hi-IN"; "en" -> "en-IN"; "bn" -> "bn-IN"; "ta" -> "ta-IN"; "te" -> "te-IN"
            "mr" -> "mr-IN"; "gu" -> "gu-IN"; "kn" -> "kn-IN"; "ml" -> "ml-IN"; "pa" -> "pa-IN"
            "ur" -> "ur-IN"; "es" -> "es-ES"; "fr" -> "fr-FR"; "de" -> "de-DE"; "ar" -> "ar-SA"
            "ru" -> "ru-RU"; "ja" -> "ja-JP"; "ko" -> "ko-KR"; "zh" -> "zh-CN"
            else -> c
        }
    }

    /** Text zyada tar Roman (A-Z) hai? Hinglish ko pehchanne ke liye. */
    fun isRoman(t: String): Boolean {
        val letters = t.filter { it.isLetter() }
        if (letters.isEmpty()) return false
        return letters.count { it.code < 0x250 } * 100 / letters.length > 80
    }

    /** Bolne se pehle code, markdown, links hata deta hai taaki awaaz saaf aaye. */
    fun cleanForSpeech(t: String): String {
        var s = Regex("```[\\s\\S]*?```").replace(t, " ")
        s = Regex("`([^`]*)`").replace(s, "$1")
        s = Regex("https?://\\S+").replace(s, " ")
        s = Regex("[*#_>|~]+").replace(s, " ")
        s = Regex("^\\s*[-•]\\s+", RegexOption.MULTILINE).replace(s, "")
        s = Regex("\\s+").replace(s, " ").trim()
        return s.take(1800)
    }
}
