# Keep runtime annotations and metadata used by Android/Kotlin.
-keepattributes *Annotation*,InnerClasses,EnclosingMethod,Signature
# Android-instantiated components are declared in AndroidManifest.xml; R8 sees those declarations.
# Do not put API keys, passwords, or signing credentials in the APK.
