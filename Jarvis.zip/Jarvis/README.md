# JARVIS (Android, sab features ek project mein)

## Build (Android Code Studio / Android Studio)
1. Zip extract karo, project folder kholo.
2. Build > Build APK. Install karo.
3. App kholo, phir ⚙ Settings mein:
   - Gemini API key daalo (aistudio.google.com)
   - Phone control: Accessibility ON karo
   - Notification access ON karo
   - Brightness control ON karo
   - Message padh ke batao: ON (optional, API use badhta hai)
   - Wake word ON karo (optional, foreground service)
4. Termux ke liye: ~/.termux/termux.properties mein allow-external-apps=true likho, Termux restart karo.

## Kya kaise bolna hai
- Chhoti baatein: "hi", "bore ho raha hoon", "mood badlo"
- Phone: "youtube pe arijit singh chalao", "spotify pe kesariya bajao", "aage", "peeche", "pause", "volume badhao", "torch on", "battery kitni hai", "brightness 50"
- Calls/SMS/WhatsApp: "rahul ko call karo", "rahul ko sms bhejo ...", "rahul ko whatsapp message bhejo ...". JARVIS pehle "haan" maangega.
- Notifications: "notification padho", "reply: kal milte hain" (haan se bhejega)
- Yaad: "yaad rakho ...", "kya yaad hai", "note karo ...", "mere notes"
- Camera: "ye kya hai" (photo lekar batayega)
- Files: "pdf banao <topic>", "word banao <topic>", "excel banao <topic>"
- Image: "image banao <kuch>"
- Monster: "monster kholo", "monster band karo"
- Termux: "termux install python", "termux mein <command>" (haan se chalega)

## Limitations
- Ye code compile/test nahi hua. Build error aaye to uska message dena.
- Wake word Hindi mein phone ke speech recognizer par depend karta hai.
- Cohere/ChatGPT, Edge-TTS, desktop Maya functions abhi nahi hain.
- Gemini ki accuracy 100% nahi hai. Sensitive kaam (call, message) user ki confirmation se hi hote hain.

## v2 naye commands
- "play store pe <app> install karo" / "<app> download karo": Play Store search khulega, install aap tap karenge
- "google se <app> apk dhoondo": Google par official APK ka search khulega (download aap khud karenge)
- "aaj ki photos dikhao": latest photos ki list
- "photo delete karo" / "3 photos delete karo": pehle "haan" maangega, phir Android ka confirmation popup
- "photo WhatsApp par bhejo": WhatsApp share screen khulegi, contact aap chunenge
- "photo lo": camera khulega, photo aap click karenge

Safety: Jarvis bina aapki confirmation ke na delete karta hai, na kisi ko message bhejta hai, na APK install karta hai.
Note: Ye code Android SDK ke bina test nahi hua hai. Build error aaye to message bhejiye.

## v4 (final) — kya badla
- API key ab encrypted store (EncryptedSharedPreferences) mein hai. Purani plain-text key apne aap migrate ho jaati hai.
- Gemini key URL mein nahi, header (x-goog-api-key) mein jaati hai.
- Gemini model band ho to agla model apne aap try hota hai (gemini-flash-latest -> gemini-3.8-flash -> gemini-3.5-flash-lite).
- Gemini errors ka saaf message: key galat, limit khatam, server busy, etc.
- Chat history app band hone ke baad bhi yaad rehti hai (last 40 messages).
- Hindi awaaz na mile to English awaaz par fallback, aur chat mein batata hai ki Hindi data install karo.
- Unit tests: Persona (mood tag parse) aur LocalBrain. Chalane ke liye: ./gradlew test

## Pehle se aaye features (v2, v3)
- Play Store search, Google par APK search (download aap karte hain), photos dekhna/delete (Android confirmation ke saath), photo WhatsApp par share (contact aap chunte hain), photo lena.
- Home page: blue monster (vision core) poori screen par, neeche type box aur mic. Jawab bolkar aur likh kar dono.
- HOME category: Jarvis ko default launcher bana sakte hain.

## Abhi bhi baaki (code se nahi hoga)
- Ye code Android SDK ke bina compile/test nahi hua. Pehli build par error aa sakte hain, unhe theek karna hoga.
- Play Store par publish ke liye SMS, Call log, Accessibility aur Notification permissions ka policy declaration zaroori hai.
- Release build mein minify/ProGuard band hai. Publish se pehle enable karke test karein.
- Strings (Hinglish) code mein hard-coded hain, multi-language ke liye strings.xml mein shift karna baaki hai.
- Accessibility service sirf phone control ke liye hai; screen content padhne ka code abhi khaali hai.
- Termux wali neural awaaz (edge-tts) Android app mein nahi hai, yahan phone ka TTS hai.

## v5 — naya home + monster controls
- Home: Claude jaisa saaf screen. "Happy <din>, <naam>" greeting (naam Settings mein badlo).
- Upar ☰ = Settings, 👾 = monster kholo.
- Neeche type box ke bagal mein 🎤 = voice-talk mode. Chalu karo to JARVIS sunta hai, jawab deta hai, phir wapas sunne lagta hai. ■ dabao to band.
- Har jawab likha bhi jata hai aur bola bhi jata hai.
- Monster: webcam se SIR ghumao, monster bhi ghoomega. Haath ki MUTTHI banao to monster CRUSH ho jaata hai (haath kholo to wapas phoolta hai). Band karne ke liye ✕ dabao. CENTER button se sidha (center) reset karo.
- Monster ke liye camera permission pehli baar maangi jayegi.
- Note: head/fist tracking browser-jaisi MediaPipe library se hai (internet chahiye, pehli baar load hogi). Purane phone par slow lag sakta hai.

## v6 — naya (dark theme, hand control, languages, USB cast, Bluetooth remote)
- Gemini model update: `gemini-flash-latest` -> `gemini-3.8-flash` -> `gemini-3.5-flash-lite`. Image: `gemini-nano-banana-2.1`. (404 wali dikkat yahi thi.)
- Poora dark theme (home, settings, Bluetooth screen). Home ka orange sparkle hata kar JARVIS ka logo (laal ring + core) laga hai; app icon bhi wahi.
- Monster: neeche camera preview + haath ki skeleton dikhti hai. Khula haath hilao = monster ghoomega. Sirf ungli+angutha (baaki ungliyan mudi) ka faasla = zoom. Mutthi = monster crush 💥 (crush sirf AI mode mein). AI load na ho to BASIC mode (skin+movement) chalta hai. Pehli baar internet chahiye (MediaPipe load).
- App kholte hi saari runtime permissions maangta hai, phir Accessibility / Notification access / Settings-write ke liye ek-ek karke guide karta hai (Android ye teen sirf Settings screen se allow karne deta hai, app khud nahi kar sakti).
- Padhai, homework, coding, maths: Persona mein step-by-step samjhane wale rules. Code chat mein dikhta hai, bola nahi jaata.
- Bhasha: Settings > Bhasha (Auto ya 18 bhashayein). Auto mein jis bhasha mein baat karo, usi mein jawab aur wahi awaaz. Hindi jawab Devanagari mein aata hai aur TTS dheemi, saaf speed par bolta hai. Local (Hinglish) jawab bolne se pehle Gemini se Devanagari mein badle jaate hain.
- Naye commands: "bhasha english", "cast karo", "bluetooth remote kholo", "screenshot lo", "lock karo", "power menu", "quick settings", "swipe left/right/up/down", "<text> pe click karo", "screen padho".
- Settings > "USB juda to Cast notification": ON karne par USB cable juda to notification aata hai; tap = Cast screen (TV/Chromecast/Miracast).
- Bluetooth Remote: phone Bluetooth keyboard + mouse + media remote ban jaata hai (Android 9+). Computer/laptop/TV/phone se pehle pair karo, phir app mein device chuno.

### Limits (sach)
- USB se connected computer/TV ko poora control karna Android app se mumkin nahi (iske liye root ya PC par scrcpy/adb chahiye). Screen cast sirf wireless (Cast/Miracast) se hota hai.
- Bluetooth se AC, speaker jaise device ko "poora control" nahi hota: speaker/headphone sirf audio ke liye connect hote hain; AC ke liye uska apna app ya IR blaster chahiye. Keyboard/mouse/remote wale control sirf un devices par chalte hain jo Bluetooth HID support karte hain. Kuch phones (Samsung/Xiaomi) mein HID profile band hoti hai.
- HID se sirf English/ASCII text type hota hai (Hindi nahi).
- Ye code Android SDK ke bina compile/test nahi hua. Build error aaye to message bhejna.

## v7 (version 3.0) — splash + gallery + photo edit
- App kholte hi animation: laal rings andar se phailti hain, ghoomti hain, core flash hota hai, "JARVIS" likha aata hai, phir home par fade. (SplashActivity.kt)
- Logo: dark background par laal ring + core (app icon wahi hai).
- Home par [+] ab camera nahi, GALLERY kholta hai. Photo chunne ke baad likho/bolo:
  - "ye kya hai?" -> Gemini photo dekh kar batata hai
  - "background hata do", "cartoon bana do", "brightness badhao" -> Gemini photo edit karta hai, result Gallery > Pictures/Jarvis mein save hota hai. Agla edit usi nayi photo par chalta hai.
  - "photo hatao" -> chuni hui photo clear.
- Photo 1600px tak chhoti karke bheji jaati hai (API kam lagta hai).
- "capcut kholo" -> CapCut khulta hai (pehle se maujood "<app> kholo" command).
- Version: 3.0 (versionCode 3).

### Limits (sach)
- Script se pro video (Veo/Sora jaisa) ke liye alag video-generation API chahiye, jo free key par aam taur par nahi milti. Abhi app mein ye nahi hai.
- CapCut ko khud video edit karwana Android se bharosemand tareeke se mumkin nahi (CapCut ka koi public automation API nahi). Sirf kholna hota hai.
- Dusron ke app/APK ko reverse-engineer karke clone banana ya do games ko mix karke APK dena is app mein nahi hai.
- Ye code Android SDK ke bina compile/test nahi hua. Build error aaye to message bhejna.

## v7.1 — naye commands
- "github search <kuch>" -> top 5 repos (bina key). "github clone owner/repo" -> Termux mein clone (haan ke baad).
- "game banao <idea>" -> original HTML5 game file (2-3 games ke mechanics ka idea likh sakte ho; copy nahi hoga). Browser mein khulti hai.
- "file banao notes.txt <topic>" -> kisi bhi extension ki file (txt, json, py, mcfunction...).
- "capcut mein video edit karo" -> gallery se video chuno, CapCut mein khul jaati hai.
- Abhi bhi nahi: script se video generation (video API chahiye), dusron ke app/APK reverse-engineer karke clone, CapCut ko khud edit karwana.

## v7.2 — APK analysis (sirf dekhna)
- "apk info /sdcard/x.apk" -> package, permissions, file list (Termux mein aapt/unzip).
- "apk decompile /sdcard/x.apk" -> jadx se code padhne ke liye ~/jadx_out mein nikalta hai (Termux mein `pkg install jadx` pehle).
- Sirf apne app, open-source app ya security samajhne ke liye. Repack/re-sign/clone ka koi command nahi hai.

## v7.3 — app banana
- "app banao <idea>" -> original Android project zip (Kotlin). Extract karke Android Studio mein Build > Build APK. Kisi doosre app ki copy nahi, sirf tumhare idea se.

## v8 (version 3.1) — Connected device control (permission ke saath)
Phone Bluetooth keyboard + mouse + media remote ban kar jo device connected hai use control karta hai.

### Kaise chalayein
1. Device (computer/laptop/TV/doosra phone) ko phone se Bluetooth pair karo.
2. "bluetooth remote kholo" bolo aur device chuno (ya "<device ka naam> se connect karo").
3. Bolo: "jo device connected hai use control karo". Jarvis device ka naam dikhakar permission maangega. "haan" bolo.
4. Ab: 
   - "device pe youtube arijit singh chalao" (pehla result), "device pe youtube arijit singh search karo" (list)
   - "device pe google python tutorial"
   - "device pe anime naruto lagao", "device pe movie <naam> lagao", "device pe webstory <naam> lagao" (YouTube search; official/legal source aap chunte ho)
   - "device pe example.com kholo"
   - "device pe download <link>" (har baar alag 'haan' maangega), "device pe downloads kholo"
   - "device pe play store <app/game> install karo" (Play Store khulta hai; Install aap dabate ho)
   - "device pe ok / neeche / upar / play / fullscreen / volume badhao / scroll neeche / type <text>"
5. Band karne ke liye: "device control band karo".
Galat type pehchana ho to: "ye mac hai" / "ye windows hai" / "ye linux hai" / "ye android hai" / "ye tv hai".

### Safety
- Permission sirf usi device ke liye, disconnect hote hi ya 30 min kuch na karne par khatam.
- Download ke liye alag confirmation. Har step ka link/text chat mein dikhta hai.

### Limits (sach)
- USB cable se TV/computer ko control karna Android app se mumkin nahi (root ya PC par scrcpy/adb chahiye). USB juda to notification Bluetooth/Cast ka rasta batata hai.
- Ye keyboard-mouse ki tarah kaam karta hai: browser/app ka khulna device ke OS aur speed par depend karta hai (Windows: Win+R, Mac: Spotlight+Safari, Android: Meta+B, Linux: browser pehle se khula ho). Timing alag ho to kabhi step chhoot sakta hai.
- TV par URL/browser nahi khulta; sirf remote keys (home, ok, arrows, type, play, volume).
- "chalao" wala pehla-result Google ke "I'm Feeling Lucky" par tika hai, kabhi galat video aa sakta hai.
- Computer par Play Store web se install aapke Google account ke phone/tablet par hota hai, computer par nahi.
- Hindi text type nahi hota (sirf English/ASCII). Kuch phones (Samsung/Xiaomi) mein Bluetooth HID band hoti hai.
- Ye code Android SDK ke bina compile/test nahi hua. Build error aaye to message bhejna.

## v8.1 — browser movie/anime, emotions, photo samjhana, AI prompt
- **Movie/anime browser mein:** "movie inception lagao", "browser me anime naruto lagao" (phone ke browser mein) ya "device pe movie ... lagao" (connected device par). Google search free + legal sources par (YouTube, Tubi, Pluto TV, Internet Archive / Crunchyroll) khulti hai. Pirated sites nahi kholta.
- **GTA V:** "gta v browser me kholo" -> Rockstar ka official page. Unofficial browser port (fiveplay.lol jaise) nahi kholta: wo leaked code par bana, copyright ke against, aur safety report mein risky.
- **Emotions + dost wali baat:** khushi, gussa, dukh, nakhra, pyaar, thakaan sab dikhte hain. Halki dosti wali gaali (pagal, bewakoof, kamine...) ON hai; "gali band karo" / "gali chalu karo". Jaat, dharm, gender, body, parivaar par kabhi nahi. Dukhi/pareshan ho to gaali nahi hoti.
- **Photo + sawal:** photo chuno (+), phir "ye kya hai?". Jawab: kya hai, kis kaam aata hai, example, sawal/maths ho to step-by-step hal, saaman ho to use aur safety.
- **AI prompt:** "prompt banao ek cyberpunk shehar 200 word" (jitne word bolo, max 3000; "lamba/bahut lamba/chhota" bhi chalta hai). "video prompt banao ... 150 word" -> scene-by-scene prompt. Phir "is prompt se image banao" -> image bante hai.
- **Video banana:** app mein nahi hai (alag paid video API chahiye). Video prompt bana kar Veo/Kling/Runway mein paste karo.
- Ye code Android SDK ke bina compile/test nahi hua.


## v9 (version 3.2) — APK workspace + Android project build

JARVIS now sends confirmed build/decode/rebuild jobs to Termux. It is intended for APKs the user owns or has explicit permission to modify.

### Termux one-time setup

```bash
pkg update
pkg install openjdk-17 git apktool apksigner
termux-setup-storage
mkdir -p ~/jarvis_apk_work ~/.keystore
```

In `~/.termux/termux.properties`, enable `allow-external-apps=true`, restart Termux, and grant JARVIS the Termux RUN_COMMAND permission when Android asks.

### Commands

- `apk edit prepare /storage/emulated/0/Download/myapp.apk` — decode an APK into `~/jarvis_apk_work/myapp/` (smali/resources).
- Edit files in that decoded folder using a code editor. Do not expect JADX Java output to be directly rebuildable; JADX is primarily for reading.
- `apk edit build ~/jarvis_apk_work/myapp` — rebuild with apktool and sign as `~/jarvis_apk_work/modified-signed.apk` using a local debug key.
- `android build /storage/emulated/0/MyAndroidProject` — run `./gradlew assembleDebug` for an Android Studio/Gradle source project.

Every build/decode command asks for `haan` before Termux runs it. Install packages only from trusted sources.

### Important limits

- This is not a universal APK editor. Some APKs use split APKs, app bundles, native libraries, obfuscation, packed/encrypted code, resource formats, or build steps that apktool cannot reproduce.
- Rebuilt APKs get a different signing certificate. They generally cannot update the original installed app; Android may require uninstalling the original first, which can erase its local data.
- This does not bypass DRM, licensing, signature checks, anti-tamper protections, account controls, or paid features. It does not modify apps without authorization.
- APK rebuild/signing and Gradle builds run in Termux, not inside the APK process. Storage access and enough free space are required.
- The project has not been compiled on an Android SDK in this environment.


## v10 (version 3.3) — Permission-based incoming call assistant

- Settings mein `Incoming call assistant setup karo` dabakar Android ke system prompt se JARVIS ko default Phone app banana hoga. Android 10+ par RoleManager ka system consent screen use hota hai.
- Incoming SIM call par JARVIS Answer/Decline screen dikhata hai. **Call sirf tab answer hoti hai jab user `Answer + Speaker ON` tap kare.** Decline button call reject karta hai. Koi auto-answer nahi hai.
- Answer ke baad speaker route select hota hai aur JARVIS ek fixed greeting TTS se bolta hai. Call end button available hai.
- Android default dialer role dene par JARVIS basic outgoing number dial screen bhi provide karta hai. Role wapas system Phone app ko Settings se diya ja sakta hai.
- Limitation: ye feature isi phone ki SIM/Telecom incoming calls ke liye hai; kisi doosre vyakti ke phone ko remotely answer nahi karta. JARVIS greeting bolta hai, lekin is build mein caller ki awaaz ko AI se transcribe karke automatic two-way conversation karne ka feature nahi hai. Audio recording/upload bhi add nahi kiya gaya.
- Android/OEM background-launch aur Telecom behavior alag ho sakta hai. Feature tabhi chalega jab user JARVIS ko default Phone app role de aur phone us role ko support kare.

## v3.4 — Monster update
- Monster ab BLUE hai.
- Camera box chhota kar ke neeche-right kone mein rakha, taaki monster ke liye screen khali rahe.
- Haath ke movement se monster ghoomta hai; mutthi banao to crush (chingaariyan + dabna), haath kholo to wapas.


## v8 UI polish and release hardening
- Splash animation now ends with a slower fade, a light-grey backdrop, a restrained monochrome logo, and a short UI tone.
- Settings use a light-grey panel; primary action accents are blue. Settings rows use switches for the permissions/features they represent.
- The Phone control master switch guides you through Android's Accessibility, Notification access, and Modify system settings screens. Android intentionally requires the device owner to approve these special permissions; the app cannot silently grant them.
- Release builds enable R8 minification and resource shrinking.

## Important security limits
- This project cannot make Android APK code impossible to inspect, copy, patch, or repackage. R8 makes reverse engineering less convenient, not impossible.
- The source files in this ZIP are readable by anyone who receives the ZIP. Do not share the source ZIP if you want to keep your source private.
- To make an APK installable as your official build, sign release builds with a private keystore that you create and keep offline. Never place the keystore or its passwords in this project or share them. Anyone can still build a differently signed copy from source; Android's package/signature checks prevent that copy from updating your already-installed app without your signing key.
- Do not store API keys or other secrets directly in source code or assets. Client-side API keys can be extracted from an APK; use a server-side proxy for sensitive credentials.
- Android special permissions remain under the user's control. The Phone control switch cannot turn on Accessibility or Notification access without the user confirming in Android Settings.


## API key usage notes

- JARVIS sends a request with one configured Gemini key; it does not ping all six keys for every message.
- It moves to another configured key only after a quota/rate-limit response (HTTP 429). Duplicate keys are skipped.
- Quota-limited slots are shown in grey and become eligible for a retry after the local cooldown; the provider's actual reset schedule may differ.
- Six keys do not guarantee all-day availability. Keys belonging to the same Google Cloud project/account may share quotas, and provider limits, billing, model availability, and terms still apply. Do not create or rotate keys to evade provider limits.
- Keep API keys private. For a production app, put provider credentials behind a backend rather than shipping them in an APK.

## Smart 6-key failover

JARVIS chooses a configured Gemini key only when a Gemini-backed feature is requested. It keeps using the current key while it works; it does not rotate keys on every message. For a request, it moves to another configured key when the current key reports quota exhaustion (429), an invalid/revoked key (401/403), an unavailable model for that key (404), or a temporary provider/server failure (5xx). A malformed request (400) is returned directly instead of pointlessly consuming other keys. Quota-full and invalid keys are shown grey in Settings. Editing/saving keys clears their stored status; the manual reset clears status flags too. Conversation history is stored separately from API-key selection and is retained across a key switch.

Note: multiple keys do not create extra quota if Google applies a shared project/account quota. No client can guarantee all-day availability or silently bypass provider limits. Use keys only for projects/accounts you are authorized to use, and check Google's current quota and billing terms.
